"use strict";
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const STATE_TXT = { running: "運行中", starting: "啟動中", stopping: "關閉中", stopped: "已停止", installing: "安裝中", not_installed: "未安裝" };

let META = null, servers = [], sel = null, tab = "console", es = null, knownPlayers = [];

async function api(method, url, body) {
  const opt = { method, headers: {} };
  if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
  const r = await fetch(url, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}
function toast(msg, err) {
  const t = $("#toast"); t.textContent = msg; t.className = "toast" + (err ? " err" : ""); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => t.hidden = true, err ? 6000 : 3000);
}
const fmtSize = n => n > 1 << 30 ? (n / (1 << 30)).toFixed(2) + " GB" : n > 1 << 20 ? (n / (1 << 20)).toFixed(1) + " MB" : (n / 1024).toFixed(0) + " KB";
const fmtTime = t => t ? new Date(t * 1000).toLocaleString("zh-TW", { hour12: false }) : "—";
const cur = () => servers.find(s => s.id === sel);

// ================================================================ 伺服器清單
async function loadServers() {
  try { servers = (await api("GET", "/api/servers")).servers; } catch { return; }
  const ul = $("#serverList");
  ul.innerHTML = servers.map(s => `<li data-id="${s.id}" class="${s.id === sel ? "sel" : ""}">
    <div class="nm"><span class="dot ${s.state}"></span>${esc(s.name)}</div>
    <div class="meta">${esc(META?.types[s.type]?.name || s.type)} ${esc(s.mc_version)} · :${esc(s.port)}${s.state === "running" ? ` · ${s.online.length} 人` : ""}</div></li>`).join("");
  $$("li", ul).forEach(li => li.onclick = () => select(li.dataset.id));
  if (sel && !cur()) { sel = null; showDetail(); }
  updateHead();
}

function select(id) {
  if (sel === id) return;
  sel = id;
  $$("#serverList li").forEach(li => li.classList.toggle("sel", li.dataset.id === id));
  showDetail();
  updateHead();
  openConsole();
  switchTab(tab);
  if (tab !== "players") loadPlayers().catch(() => { });
}

function showDetail() {
  $("#empty").hidden = !!sel; $("#detail").hidden = !sel;
  if (!sel && es) { es.close(); es = null; }
}

function updateHead() {
  const s = cur(); if (!s) return;
  $("#dName").textContent = s.name;
  const b = $("#dState"); b.textContent = STATE_TXT[s.state] || s.state; b.className = "badge " + s.state;
  const up = s.started_at ? ` · 已運行 ${Math.floor((Date.now() / 1000 - s.started_at) / 60)} 分鐘` : "";
  $("#dInfo").textContent = `${META?.types[s.type]?.name || s.type} ${s.mc_version}${s.loader_version ? " (" + s.loader_version + ")" : ""} · 連接埠 ${s.port} · Java ${s.java ?? "?"} · ${s.mem_max}${s.state === "running" ? ` · 在線 ${s.online.length}${s.max_players ? "/" + s.max_players : ""}` : ""}${up}`;
  const on = !!s.pid, busy = ["installing", "starting", "stopping"].includes(s.state);
  const en = { start: !on && s.state === "stopped", stop: on && s.state !== "stopping", restart: on, save: s.state === "running", kill: on };
  $$(".actions [data-act]").forEach(b => b.disabled = !en[b.dataset.act]);
  $("#cmdSend").disabled = !on;
  $("#btnReinstall").disabled = on || busy;
  $("#btnDelete").disabled = on || busy;
}

$$(".actions [data-act]").forEach(b => b.onclick = async () => {
  const act = b.dataset.act;
  if (act === "kill" && !confirm("強制結束不會存檔，確定嗎？")) return;
  try { await api("POST", `/api/servers/${sel}/${act}`); if (act === "save") toast("已存檔 (save-all)"); }
  catch (e) { toast(e.message, true); }
  loadServers();
});

// ================================================================ 分頁
$$(".tabs button").forEach(b => b.onclick = () => switchTab(b.dataset.tab));
function switchTab(t) {
  tab = t;
  $$(".tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === t));
  $$(".tab").forEach(d => d.hidden = d.id !== "tab-" + t);
  if (!sel) return;
  if (t === "players") loadPlayers();
  if (t === "files") loadFiles();
  if (t === "props") loadProps();
  if (t === "settings") loadSettings();
  if (t === "map") mapOpen();
  if (t === "console") scrollConsole(true);
}

// ================================================================ 主控台
const consoleEl = $("#console");
function lineClass(it) {
  if (it.kind !== "log") return it.kind;
  const t = it.text;
  if (/\/(WARN)\]|\sWARN\]/.test(t)) return "warn";
  if (/\/(ERROR|FATAL)\]|\s(ERROR|FATAL)\]|Exception/.test(t)) return "err";
  if (/joined the game|left the game/.test(t)) return "join";
  if (/\]: (\[Not Secure\] )?<[^>]+>/.test(t)) return "chat";
  return "";
}
function addLine(it) {
  const d = document.createElement("div");
  d.className = lineClass(it); d.textContent = it.text;
  consoleEl.appendChild(d);
  while (consoleEl.childElementCount > 1500) consoleEl.firstChild.remove();
}
function scrollConsole(force) { if (force || $("#autoscroll").checked) consoleEl.scrollTop = consoleEl.scrollHeight; }
function openConsole() {
  if (es) es.close();
  consoleEl.innerHTML = "";
  const id = sel;
  es = new EventSource(`/api/servers/${id}/console`);
  let pending = [], raf = 0;
  es.onmessage = ev => {
    if (id !== sel) return;
    pending.push(JSON.parse(ev.data));
    if (!raf) raf = requestAnimationFrame(() => { pending.forEach(addLine); pending = []; raf = 0; scrollConsole(); });
  };
}

// ---- 指令輸入 + 自動補全 + 歷史
const input = $("#cmdInput"), sug = $("#suggest");
let history = JSON.parse(localStorage.getItem("mcm_hist") || "[]"), hIdx = -1, sugItems = [], sugIdx = 0;

function playerCandidates() {
  const s = cur();
  return [...new Set([...(s?.online || []), ...DYN.$selectors, ...knownPlayers])];
}
function expand(spec) {
  if (spec == null) return { list: [], hint: "" };
  if (Array.isArray(spec)) return { list: spec, hint: "" };
  if (typeof spec === "object") return { list: Object.keys(spec), hint: "<子指令>" };
  if (spec === "$player") return { list: playerCandidates(), hint: "<玩家>" };
  if (spec === "$text") return { list: [], hint: "<文字>" };
  const l = DYN[spec] || [];
  return { list: l, hint: "<" + spec.slice(1) + ">" };
}
function computeSuggest() {
  const v = input.value;
  if (!v.startsWith("/")) return [];
  const toks = v.slice(1).split(" ");
  const curTok = toks.pop().toLowerCase();
  if (toks.length === 0) {
    return Object.keys(COMMANDS).filter(c => c.startsWith(curTok)).sort().map(c => ({ v: c, h: "" }));
  }
  let spec = COMMANDS[toks[0].toLowerCase()];
  if (!spec) return [];
  for (const t of toks.slice(1)) {
    if (!spec.length) return [];
    const el = spec[0];
    if (el && typeof el === "object" && !Array.isArray(el)) spec = el[t] || [];
    else if (el === "$text") return [];
    else spec = spec.slice(1);
  }
  const { list, hint } = expand(spec[0]);
  const flt = list.filter(x => x.toLowerCase().startsWith(curTok) || x.toLowerCase().startsWith("minecraft:" + curTok));
  if (!flt.length && hint) return [{ v: null, h: hint }];
  return flt.slice(0, 60).map(x => ({ v: x, h: hint }));
}
function renderSuggest() {
  sugItems = computeSuggest(); sugIdx = 0;
  if (!sugItems.length || (sugItems.length === 1 && sugItems[0].v && input.value.endsWith(sugItems[0].v))) { sug.hidden = true; return; }
  sug.innerHTML = sugItems.map((s, i) => `<li data-i="${i}" class="${i === sugIdx && s.v ? "sel" : ""}"><span>${esc(s.v ?? "")}</span><span class="hint">${esc(s.h)}</span></li>`).join("");
  sug.hidden = false;
  $$("li", sug).forEach(li => li.onmousedown = e => { e.preventDefault(); sugIdx = +li.dataset.i; accept(); });
}
function accept() {
  const s = sugItems[sugIdx]; if (!s || !s.v) return false;
  const v = input.value, i = v.lastIndexOf(" ");
  input.value = (i < 0 ? "/" : v.slice(0, i + 1)) + s.v + " ";
  renderSuggest(); return true;
}
function moveSel(d) {
  sugIdx = (sugIdx + d + sugItems.length) % sugItems.length;
  $$("li", sug).forEach((li, i) => li.classList.toggle("sel", i === sugIdx));
  $$("li", sug)[sugIdx]?.scrollIntoView({ block: "nearest" });
}
input.addEventListener("input", () => { hIdx = -1; renderSuggest(); });
input.addEventListener("blur", () => setTimeout(() => sug.hidden = true, 100));
input.addEventListener("keydown", e => {
  const open = !sug.hidden && sugItems.some(s => s.v);
  if (e.key === "Tab") { e.preventDefault(); if (open) accept(); }
  else if (e.key === "ArrowUp" || e.key === "ArrowDown") {
    e.preventDefault();
    if (open) moveSel(e.key === "ArrowUp" ? -1 : 1);
    else if (history.length) {
      hIdx = e.key === "ArrowUp" ? Math.min(hIdx + 1, history.length - 1) : Math.max(hIdx - 1, -1);
      input.value = hIdx < 0 ? "" : history[hIdx];
    }
  } else if (e.key === "Escape") sug.hidden = true;
  else if (e.key === "Enter") { e.preventDefault(); sendCmd(); }
});
$("#cmdSend").onclick = sendCmd;
async function sendCmd() {
  const v = input.value.trim(); if (!v) return;
  try {
    await api("POST", `/api/servers/${sel}/command`, { command: v });
    history = [v, ...history.filter(h => h !== v)].slice(0, 100);
    localStorage.setItem("mcm_hist", JSON.stringify(history));
    input.value = ""; hIdx = -1; sug.hidden = true; scrollConsole(true);
  } catch (e) { toast(e.message, true); }
}

// ================================================================ 玩家
async function loadPlayers() {
  if (document.activeElement?.classList.contains("note")) return; // 正在輸入備註時不要刷新
  const id = sel;
  const { players } = await api("GET", `/api/servers/${id}/players`);
  if (id !== sel) return;
  knownPlayers = players.map(p => p.name);
  const row = p => `<tr data-name="${esc(p.name)}">
    <td><img class="head" src="https://mc-heads.net/avatar/${encodeURIComponent(p.name)}/24" onerror="this.style.visibility='hidden'" alt=""></td>
    <td><b>${esc(p.name)}</b>${p.op ? '<span class="tag op">OP</span>' : ""}${p.banned ? '<span class="tag ban">封鎖</span>' : ""}</td>
    <td><input class="note" value="${esc(p.note || "")}" placeholder="點此輸入備註…"></td>
    <td class="uuid">${esc(p.uuid || "")}</td>
    <td class="small">${p.online ? "🟢 線上" : fmtTime(p.last_seen)}</td>
    <td class="small">${p.online ? `<button class="btn small" data-c="kick">踢出</button>` : ""}
      <button class="btn small" data-c="${p.op ? "deop" : "op"}">${p.op ? "取消OP" : "給OP"}</button>
      <button class="btn small" data-c="${p.banned ? "pardon" : "ban"}">${p.banned ? "解封" : "封鎖"}</button>
      ${p.online ? "" : `<button class="btn small ghost" data-c="forget" title="從清單移除">✕</button>`}</td></tr>`;
  const on = players.filter(p => p.online), off = players.filter(p => !p.online);
  $("#onlineCount").textContent = `(${on.length})`;
  $("#playersOnline").innerHTML = on.map(row).join("") || `<tr><td colspan="6" class="muted">目前沒有玩家在線</td></tr>`;
  $("#playersOffline").innerHTML = off.map(row).join("") || `<tr><td colspan="6" class="muted">沒有紀錄</td></tr>`;
  $$("#tab-players tr[data-name]").forEach(tr => {
    const name = tr.dataset.name;
    const note = $("input.note", tr);
    note.onchange = () => api("PUT", `/api/servers/${sel}/players/${encodeURIComponent(name)}`, { note: note.value })
      .then(() => toast("備註已儲存")).catch(e => toast(e.message, true));
    $$("button[data-c]", tr).forEach(b => b.onclick = async () => {
      const c = b.dataset.c;
      try {
        if (c === "forget") await api("DELETE", `/api/servers/${sel}/players/${encodeURIComponent(name)}`);
        else {
          if ((c === "ban" || c === "kick") && !confirm(`確定要${c === "ban" ? "封鎖" : "踢出"} ${name}？`)) return;
          await api("POST", `/api/servers/${sel}/command`, { command: `/${c} ${name}` });
        }
        setTimeout(loadPlayers, 600);
      } catch (e) { toast(e.message, true); }
    });
  });
}

// ================================================================ 檔案
async function loadFiles() {
  const s = cur(); if (!s) return;
  const ad = s.addon_dir;
  $("#addonTitle").textContent = ad === "plugins" ? "插件 plugins" : ad === "mods" ? "模組 mods" : "模組 / 插件";
  const addonCard = $("#addonTitle").parentElement;
  addonCard.hidden = !ad;
  if (ad) renderFileList("#addonList", ad, (await api("GET", `/api/servers/${sel}/files?dir=${ad}`)).files, true);
  renderFileList("#dpList", "datapacks", (await api("GET", `/api/servers/${sel}/files?dir=datapacks`)).files, false);
  const w = await api("GET", `/api/servers/${sel}/worlds`);
  $("#worldList").innerHTML = w.worlds.map(x => `<li data-n="${esc(x.name)}"><span class="fn">${x.active ? "🌍 <b>" : ""}${esc(x.name)}${x.active ? "</b>（使用中）" : ""}</span>
    <span class="sz">${fmtSize(x.size)}</span>
    <a class="btn small" href="/api/servers/${sel}/download?world=${encodeURIComponent(x.name)}" title="備份下載">⬇</a>
    ${x.active ? "" : `<button class="btn small" data-a="use">使用</button><button class="btn small ghost" data-a="del">✕</button>`}</li>`).join("")
    || `<li class="muted">還沒有世界（第一次啟動會自動產生）</li>`;
  $$("#worldList li[data-n]").forEach(li => $$("button", li).forEach(b => b.onclick = async () => {
    const n = li.dataset.n;
    try {
      if (b.dataset.a === "use") { await api("POST", `/api/servers/${sel}/worlds`, { action: "activate", name: n }); toast(`已切換為 ${n}，下次啟動生效`); }
      else { if (!confirm(`刪除世界「${n}」？無法復原！`)) return; await api("DELETE", `/api/servers/${sel}/files?path=world/${encodeURIComponent(n)}`); }
      loadFiles();
    } catch (e) { toast(e.message, true); }
  }));
}
function renderFileList(selector, dir, files, toggle) {
  $(selector).innerHTML = files.map(f => `<li class="${f.disabled ? "off" : ""}" data-n="${esc(f.name)}">
    <span class="fn">${f.dir ? "📁 " : ""}${esc(f.name.replace(/\.disabled$/, ""))}</span><span class="sz">${f.dir ? "" : fmtSize(f.size)}</span>
    ${toggle && !f.dir ? `<button class="btn small" data-a="t">${f.disabled ? "啟用" : "停用"}</button>` : ""}
    <button class="btn small ghost" data-a="d">✕</button></li>`).join("") || `<li class="muted">（空）</li>`;
  $$(selector + " li[data-n]").forEach(li => $$("button", li).forEach(b => b.onclick = async () => {
    const p = `${dir}/${li.dataset.n}`;
    try {
      if (b.dataset.a === "t") await api("POST", `/api/servers/${sel}/toggle`, { path: p });
      else { if (!confirm(`刪除 ${li.dataset.n}？`)) return; await api("DELETE", `/api/servers/${sel}/files?path=${encodeURIComponent(p)}`); }
      if (cur()?.pid) toast("變更將在重新啟動後生效");
      loadFiles();
    } catch (e) { toast(e.message, true); }
  }));
}
function uploadFiles(kind, files) {
  const s = cur(); if (!s) return;
  const realKind = kind === "addon" ? s.addon_dir : kind;
  const status = $("#uploadStatus");
  [...files].reduce((p, f) => p.then(() => new Promise(res => {
    const q = new URLSearchParams({ kind: realKind, name: f.name });
    if (kind === "world" && $("#worldActivate").checked) q.set("activate", "1");
    const box = document.createElement("div");
    box.innerHTML = `${esc(f.name)} <span></span><div class="progress"><div></div></div>`;
    status.prepend(box);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/servers/${sel}/upload?${q}`);
    xhr.upload.onprogress = e => { if (e.lengthComputable) $(".progress div", box).style.width = (e.loaded / e.total * 100) + "%"; };
    xhr.onload = () => {
      let j = {}; try { j = JSON.parse(xhr.responseText); } catch { }
      $("span", box).textContent = xhr.status < 300 ? "✔ " + (j.message || "完成") + (j.restart_needed ? "（重啟後生效）" : "") : "✘ " + (j.error || xhr.statusText);
      $(".progress", box).remove(); loadFiles(); res();
    };
    xhr.onerror = () => { $("span", box).textContent = "✘ 上傳失敗"; res(); };
    xhr.send(f);
  })), Promise.resolve());
}
$$(".drop").forEach(d => {
  const pick = document.createElement("input"); pick.type = "file"; pick.multiple = true; pick.hidden = true;
  d.appendChild(pick);
  $("button", d).onclick = () => pick.click();
  pick.onchange = () => { uploadFiles(d.dataset.kind, pick.files); pick.value = ""; };
  d.ondragover = e => { e.preventDefault(); d.classList.add("over"); };
  d.ondragleave = () => d.classList.remove("over");
  d.ondrop = e => { e.preventDefault(); d.classList.remove("over"); uploadFiles(d.dataset.kind, e.dataTransfer.files); };
});

// ================================================================ server.properties
const PROP_DESC = {
  "motd": "伺服器標語（列表中顯示）", "server-port": "連接埠", "max-players": "最大玩家數", "gamemode": "預設遊戲模式",
  "difficulty": "難度", "hardcore": "極限模式", "pvp": "允許 PvP", "online-mode": "正版驗證（關閉 = 盜版也能進）",
  "white-list": "啟用白名單", "enforce-whitelist": "強制白名單（踢出不在名單的人）", "level-name": "世界資料夾名稱",
  "level-seed": "世界種子", "level-type": "世界類型", "view-distance": "視野距離（區塊）", "simulation-distance": "模擬距離（區塊）",
  "spawn-protection": "重生點保護半徑", "allow-flight": "允許飛行（避免被誤踢）", "allow-nether": "啟用地獄",
  "spawn-monsters": "生成怪物", "spawn-animals": "生成動物", "spawn-npcs": "生成村民", "generate-structures": "生成結構",
  "enable-command-block": "啟用指令方塊", "force-gamemode": "強制遊戲模式", "max-world-size": "世界最大半徑",
  "player-idle-timeout": "閒置踢出（分鐘，0=不踢）", "op-permission-level": "OP 權限等級", "enable-rcon": "啟用 RCON",
  "rcon.port": "RCON 連接埠", "rcon.password": "RCON 密碼", "enable-query": "啟用 Query", "server-ip": "綁定 IP（通常留空）",
  "resource-pack": "資源包網址", "require-resource-pack": "強制資源包", "network-compression-threshold": "網路壓縮門檻",
  "max-tick-time": "看門狗逾時（毫秒）", "sync-chunk-writes": "同步寫入區塊", "enforce-secure-profile": "強制安全聊天簽章",
  "hide-online-players": "隱藏在線玩家", "entity-broadcast-range-percentage": "實體顯示範圍 %", "enable-status": "顯示於伺服器列表",
  "pause-when-empty-seconds": "無人時暫停（秒）", "log-ips": "紀錄玩家 IP", "accepts-transfers": "接受轉移",
};
const PROP_ENUM = {
  gamemode: ["survival", "creative", "adventure", "spectator"], difficulty: ["peaceful", "easy", "normal", "hard"],
  "level-type": ["minecraft:normal", "minecraft:flat", "minecraft:large_biomes", "minecraft:amplified", "minecraft:single_biome_surface"],
  "op-permission-level": ["1", "2", "3", "4"],
};
let propOrig = {};
async function loadProps() {
  const { properties } = await api("GET", `/api/servers/${sel}/properties`);
  propOrig = properties;
  const keys = Object.keys(properties).sort((a, b) => (PROP_DESC[b] ? 1 : 0) - (PROP_DESC[a] ? 1 : 0) || a.localeCompare(b));
  $("#propGrid").innerHTML = keys.map(k => {
    const v = properties[k];
    let ctl;
    if (v === "true" || v === "false") ctl = `<select data-k="${esc(k)}"><option value="true" ${v === "true" ? "selected" : ""}>是 (true)</option><option value="false" ${v === "false" ? "selected" : ""}>否 (false)</option></select>`;
    else if (PROP_ENUM[k]) { const opts = PROP_ENUM[k].includes(v) ? PROP_ENUM[k] : [v, ...PROP_ENUM[k]]; ctl = `<select data-k="${esc(k)}">${opts.map(o => `<option ${o === v ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>`; }
    else ctl = `<input data-k="${esc(k)}" value="${esc(v)}" ${/^-?\d+$/.test(v) ? 'inputmode="numeric"' : ""}>`;
    return `<div class="prop" data-key="${esc(k)}"><div class="d">${esc(PROP_DESC[k] || k)}</div><div class="k">${esc(k)}</div>${ctl}</div>`;
  }).join("") || `<p class="muted">還沒有 server.properties（第一次啟動後會自動產生完整設定）。</p>`;
  $$("#propGrid [data-k]").forEach(el => el.oninput = el.onchange = () => el.parentElement.classList.toggle("changed", el.value !== propOrig[el.dataset.k]));
  filterProps();
}
function filterProps() {
  const f = $("#propFilter").value.toLowerCase();
  $$("#propGrid .prop").forEach(p => p.hidden = f && !p.textContent.toLowerCase().includes(f));
}
$("#propFilter").oninput = filterProps;
$("#propSave").onclick = async () => {
  const changed = {};
  $$("#propGrid [data-k]").forEach(el => { if (el.value !== propOrig[el.dataset.k]) changed[el.dataset.k] = el.value; });
  if (!Object.keys(changed).length) return toast("沒有變更");
  try {
    const r = await api("PUT", `/api/servers/${sel}/properties`, { properties: changed });
    toast(r.restart_needed ? "已儲存，重新啟動伺服器後生效" : "已儲存"); loadProps(); loadServers();
  } catch (e) { toast(e.message, true); }
};

// ================================================================ 設定
function loadSettings() {
  const s = cur(), f = $("#setForm");
  f.name.value = s.name; f.mem_min.value = s.mem_min || "1G"; f.mem_max.value = s.mem_max || "4G";
  f.java.value = String(s.java || 21); f.jvm_args.value = s.jvm_args || ""; f.discord_webhook.value = s.discord_webhook || "";
  f.autostart.checked = !!s.autostart;
}
$("#setForm").onsubmit = async e => {
  e.preventDefault(); const f = e.target;
  try {
    await api("PUT", `/api/servers/${sel}`, { name: f.name.value, mem_min: f.mem_min.value.toUpperCase(), mem_max: f.mem_max.value.toUpperCase(),
      java: +f.java.value, jvm_args: f.jvm_args.value, discord_webhook: f.discord_webhook.value.trim(), autostart: f.autostart.checked });
    toast("設定已儲存（下次啟動生效）"); loadServers();
  } catch (err) { toast(err.message, true); }
};
$("#btnReinstall").onclick = async () => {
  if (!confirm("重新下載伺服器核心（世界與模組會保留）？")) return;
  try { await api("POST", `/api/servers/${sel}/reinstall`); switchTab("console"); } catch (e) { toast(e.message, true); }
};
$("#btnDelete").onclick = async () => {
  const s = cur();
  if (prompt(`這會刪除「${s.name}」的所有檔案（包含世界）。\n請輸入伺服器名稱確認：`) !== s.name) return;
  try { await api("DELETE", `/api/servers/${sel}`); sel = null; showDetail(); loadServers(); } catch (e) { toast(e.message, true); }
};

// ================================================================ 地圖
const cv = $("#mapCanvas"), ctx = cv.getContext("2d");
const MAP = { dims: [], dim: null, cx: 0, cz: 0, scale: 1, tiles: new Map(), ver: Date.now(), players: { online: [], offline: [] }, spawn: null, timer: 0, sid: null };
async function mapOpen() {
  if (MAP.sid !== sel) { MAP.sid = sel; MAP.tiles.clear(); MAP.dim = null; MAP.players = { online: [], offline: [] }; }
  await mapLoadDims();
  mapPollPlayers();
  clearInterval(MAP.timer);
  MAP.timer = setInterval(() => { if (tab === "map" && !document.hidden) mapPollPlayers(); else clearInterval(MAP.timer); }, 3000);
}
async function mapLoadDims() {
  const r = await api("GET", `/api/servers/${sel}/map/dims`);
  MAP.dims = r.dims; MAP.spawn = r.spawn;
  const s = $("#mapDim"); const prev = MAP.dim;
  const label = d => ({ "minecraft:overworld": "主世界", "minecraft:the_nether": "地獄", "minecraft:the_end": "終界" }[d.dim] || d.dim) + `（${d.key}）`;
  s.innerHTML = MAP.dims.map(d => `<option value="${esc(d.key)}">${esc(label(d))}</option>`).join("") || `<option value="">（尚無地形資料，請先啟動並存檔）</option>`;
  if (prev && MAP.dims.some(d => d.key === prev)) s.value = prev;
  else { MAP.dim = s.value || null; if (MAP.spawn) { MAP.cx = MAP.spawn[0]; MAP.cz = MAP.spawn[1]; } }
  MAP.dim = s.value || null;
  mapDraw();
}
$("#mapDim").onchange = e => { MAP.dim = e.target.value; mapDraw(); };
$("#mapCenter").onclick = () => { if (MAP.spawn) { MAP.cx = MAP.spawn[0]; MAP.cz = MAP.spawn[1]; } else { MAP.cx = MAP.cz = 0; } mapDraw(); };
$("#mapOffline").onchange = mapDraw;
$("#mapRefresh").onclick = async () => {
  const s = cur();
  if (s?.state === "running") { try { await api("POST", `/api/servers/${sel}/save`); } catch { } toast("已存檔，正在重新讀取地形…"); await new Promise(r => setTimeout(r, 3000)); }
  MAP.ver = Date.now(); MAP.tiles.clear(); await mapLoadDims();
};
async function mapPollPlayers() {
  try { MAP.players = await api("GET", `/api/servers/${sel}/map/players`); } catch { return; }
  const curDim = MAP.dims.find(d => d.key === MAP.dim)?.dim || "minecraft:overworld";
  const all = [...MAP.players.online.map(p => ({ ...p, on: 1 })), ...MAP.players.offline];
  $("#mapPlayers").innerHTML = all.map(p => `<span class="chip ${p.on ? "on" : ""}" data-n="${esc(p.name)}" title="${esc(p.dim)}">${p.on ? "🟢" : "⚪"} ${esc(p.name)}${p.note ? "（" + esc(p.note) + "）" : ""} · ${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)}${p.dim !== curDim ? " · " + esc(p.dim.split(":")[1]) : ""}</span>`).join("");
  $$("#mapPlayers .chip").forEach(c => c.onclick = () => {
    const p = all.find(x => x.name === c.dataset.n); if (!p) return;
    const d = MAP.dims.find(d => d.dim === p.dim);
    if (d) { MAP.dim = d.key; $("#mapDim").value = d.key; }
    MAP.cx = p.x; MAP.cz = p.z; MAP.scale = Math.max(MAP.scale, 2); mapDraw();
  });
  mapDraw();
}
function tile(x, z) {
  const k = `${MAP.dim}|${x}|${z}`;
  let t = MAP.tiles.get(k);
  if (!t) {
    t = new Image(); t.onload = mapDraw;
    t.src = `/api/servers/${sel}/map/tile?key=${encodeURIComponent(MAP.dim)}&x=${x}&z=${z}&v=${MAP.ver}`;
    MAP.tiles.set(k, t);
  }
  return t;
}
function mapDraw() {
  if (tab !== "map") return;
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  if (cv.width !== W * dpr || cv.height !== H * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#0b0d10"; ctx.fillRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = false;
  const sc = MAP.scale, toX = x => (x - MAP.cx) * sc + W / 2, toY = z => (z - MAP.cz) * sc + H / 2;
  const d = MAP.dims.find(d => d.key === MAP.dim);
  if (d) {
    const have = new Set(d.regions.map(r => r[0] + "," + r[1]));
    const x0 = Math.floor((MAP.cx - W / 2 / sc) / 512), x1 = Math.floor((MAP.cx + W / 2 / sc) / 512);
    const z0 = Math.floor((MAP.cz - H / 2 / sc) / 512), z1 = Math.floor((MAP.cz + H / 2 / sc) / 512);
    for (let rx = x0; rx <= x1; rx++) for (let rz = z0; rz <= z1; rz++) {
      if (!have.has(rx + "," + rz)) continue;
      const t = tile(rx, rz);
      if (t.complete && t.naturalWidth) ctx.drawImage(t, toX(rx * 512), toY(rz * 512), 512 * sc, 512 * sc);
      else { ctx.strokeStyle = "#2a2f38"; ctx.strokeRect(toX(rx * 512), toY(rz * 512), 512 * sc, 512 * sc); }
    }
  }
  // 重生點
  if (MAP.spawn && (!d || d.dim === "minecraft:overworld")) {
    ctx.fillStyle = "#ffd54a"; ctx.font = "12px sans-serif";
    ctx.fillText("★ 重生點", toX(MAP.spawn[0]) - 6, toY(MAP.spawn[1]) + 4);
  }
  const curDim = d?.dim || "minecraft:overworld";
  const list = [...($("#mapOffline").checked ? MAP.players.offline : []).map(p => ({ ...p, on: 0 })), ...MAP.players.online.map(p => ({ ...p, on: 1 }))];
  ctx.font = "bold 12px sans-serif";
  for (const p of list) {
    if (p.dim !== curDim) continue;
    const x = toX(p.x), y = toY(p.z);
    ctx.beginPath(); ctx.arc(x, y, 5, 0, 7);
    ctx.fillStyle = p.on ? "#4cff6a" : "#9aa0a8"; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = "#000"; ctx.stroke();
    const label = p.name + (p.note ? `（${p.note}）` : "");
    ctx.lineWidth = 3; ctx.strokeText(label, x + 8, y - 6);
    ctx.fillStyle = p.on ? "#fff" : "#c8c8c8"; ctx.fillText(label, x + 8, y - 6);
  }
}
let drag = null;
cv.onmousedown = e => { drag = { x: e.clientX, y: e.clientY, cx: MAP.cx, cz: MAP.cz }; cv.style.cursor = "grabbing"; };
window.addEventListener("mouseup", () => { drag = null; cv.style.cursor = "grab"; });
cv.onmousemove = e => {
  const r = cv.getBoundingClientRect();
  const wx = MAP.cx + (e.clientX - r.left - r.width / 2) / MAP.scale, wz = MAP.cz + (e.clientY - r.top - r.height / 2) / MAP.scale;
  $("#mapCoord").textContent = `X ${Math.floor(wx)}  Z ${Math.floor(wz)}`;
  if (drag) { MAP.cx = drag.cx - (e.clientX - drag.x) / MAP.scale; MAP.cz = drag.cz - (e.clientY - drag.y) / MAP.scale; mapDraw(); }
};
cv.onwheel = e => {
  e.preventDefault();
  const r = cv.getBoundingClientRect(), mx = e.clientX - r.left - r.width / 2, my = e.clientY - r.top - r.height / 2;
  const wx = MAP.cx + mx / MAP.scale, wz = MAP.cz + my / MAP.scale;
  MAP.scale = Math.min(16, Math.max(0.0625, MAP.scale * (e.deltaY < 0 ? 1.25 : 0.8)));
  MAP.cx = wx - mx / MAP.scale; MAP.cz = wz - my / MAP.scale; mapDraw();
};
// 觸控拖曳
cv.ontouchstart = e => { const t = e.touches[0]; drag = { x: t.clientX, y: t.clientY, cx: MAP.cx, cz: MAP.cz }; };
cv.ontouchmove = e => { e.preventDefault(); const t = e.touches[0]; if (drag) { MAP.cx = drag.cx - (t.clientX - drag.x) / MAP.scale; MAP.cz = drag.cz - (t.clientY - drag.y) / MAP.scale; mapDraw(); } };
cv.ontouchend = () => drag = null;
window.addEventListener("resize", mapDraw);

// ================================================================ 新增伺服器
const dlg = $("#dlgNew"), nf = $("#newForm");
$("#btnNew").onclick = async () => {
  nf.reset(); $("#nPort").value = META.next_port;
  try { META = await api("GET", "/api/meta"); $("#nPort").value = META.next_port; } catch { }
  dlg.showModal(); loadNewVersions();
};
$("#nType").onchange = loadNewVersions;
$("#nSnap").onchange = loadNewVersions;
$("#nVer").onchange = loadNewLoaders;
async function loadNewVersions() {
  const t = $("#nType").value, v = $("#nVer");
  v.innerHTML = "<option>載入中…</option>"; v.disabled = true;
  $("#nLoaderWrap").hidden = !META.types[t].loader;
  try {
    const { versions } = await api("GET", `/api/versions?type=${t}&snapshots=${$("#nSnap").checked ? 1 : 0}`);
    v.innerHTML = versions.map(x => `<option>${esc(x)}</option>`).join("");
    v.disabled = false; loadNewLoaders();
  } catch (e) { v.innerHTML = `<option value="">無法取得</option>`; toast(e.message, true); }
}
async function loadNewLoaders() {
  const t = $("#nType").value, l = $("#nLoader");
  if (!META.types[t].loader) { l.innerHTML = ""; return; }
  l.innerHTML = "<option>載入中…</option>";
  try {
    const { versions } = await api("GET", `/api/loaders?type=${t}&mc=${encodeURIComponent($("#nVer").value)}`);
    l.innerHTML = versions.map((x, i) => `<option value="${esc(x)}">${esc(x)}${i === 0 ? "（推薦/最新）" : ""}</option>`).join("") || `<option value="">此版本沒有可用的載入器</option>`;
  } catch (e) { l.innerHTML = ""; toast(e.message, true); }
}
nf.onsubmit = async e => {
  if (e.submitter?.value !== "ok") return;
  e.preventDefault();
  const body = Object.fromEntries(new FormData(nf));
  body.eula = nf.eula.checked; body.mem_max = (body.mem_max || "4G").toUpperCase();
  if (META.types[body.type].loader && !body.loader_version) return toast("請選擇載入器版本", true);
  try {
    const s = await api("POST", "/api/servers", body);
    dlg.close(); await loadServers(); select(s.id); switchTab("console");
    toast("開始下載與安裝，進度顯示在主控台");
  } catch (err) { toast(err.message, true); }
};

// ================================================================ 關閉管理程式
$("#btnShutdown").onclick = async () => {
  if (!confirm("要停止所有 Minecraft 伺服器（會先存檔）並關閉管理程式嗎？\n關閉後需要回到電腦重新執行才能再開啟網頁。")) return;
  try { await api("POST", "/api/shutdown"); } catch { }
  document.body.innerHTML = `<div class="empty"><h2>管理程式正在關閉…</h2><p>所有伺服器會先執行 stop（自動存檔）後結束。可以關閉這個分頁了。</p></div>`;
};

// ================================================================ 啟動
(async function init() {
  META = await api("GET", "/api/meta");
  $("#nType").innerHTML = Object.entries(META.types).map(([k, v]) => `<option value="${k}">${esc(v.name)}</option>`).join("");
  await loadServers();
  if (servers.length) select(servers[0].id);
  setInterval(loadServers, 2000);
  setInterval(() => { if (tab === "players" && sel && !document.hidden) loadPlayers(); }, 5000);
})();
