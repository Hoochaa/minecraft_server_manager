#!/usr/bin/env python3
"""Minecraft 伺服器網頁管理器 — 啟動點。

用法：python manager.py
然後用瀏覽器開啟畫面上顯示的網址（同一個區網的手機/電腦都可以連）。
"""
import signal
import socket
import sys

if sys.version_info < (3, 8):
    sys.exit("需要 Python 3.8 以上版本")

from mcm import web
from mcm.util import CONFIG


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


def main():
    manager, httpd = web.serve()
    port = httpd.server_address[1]
    print("=" * 56)
    print(" Minecraft 伺服器網頁管理器已啟動")
    print(f"   本機：  http://localhost:{port}")
    for ip in lan_ips():
        print(f"   區網：  http://{ip}:{port}")
    print(" 設定檔：data/config.json（可改連接埠、設定密碼）")
    print(" 停止：網頁右上角「關閉管理程式」或按 Ctrl+C")
    print("=" * 56)

    def on_signal(*_):
        print("\n正在停止所有 Minecraft 伺服器（會先存檔）…")
        manager.stop_all()
        sys.exit(0)
    signal.signal(signal.SIGINT, on_signal)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, on_signal)
    if hasattr(signal, "SIGBREAK"):  # Windows 關閉主控台視窗
        signal.signal(signal.SIGBREAK, on_signal)
    try:
        httpd.serve_forever(poll_interval=0.5)
    finally:
        manager.stop_all()


if __name__ == "__main__":
    main()
