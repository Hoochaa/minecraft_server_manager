"""單一 Minecraft 伺服器實例：設定、程序控制、主控台、玩家追蹤。"""
import collections
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import urllib.request
import uuid as uuidlib

from . import installer, java as javamod
from .util import SERVERS_DIR, read_json, write_json

ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07")
NAME = r"([A-Za-z0-9_.]{1,17})"
PREFIX = r"INFO\]:?(?: \[[^\]]*\])?:? "
RE_JOIN = re.compile(PREFIX + NAME + r"(?: \([^)]*\))? joined the game")
RE_LEFT = re.compile(PREFIX + NAME + r" left the game")
RE_UUID = re.compile(r"UUID of player " + NAME + r" is ([0-9a-fA-F-]{32,36})")
RE_CHAT = re.compile(PREFIX + r"(?:\[Not Secure\] )?<" + NAME + r"> (.*)$")
RE_DONE = re.compile(r"Done \([\d.,]+s\)!")
RE_LIST = re.compile(r"There are (\d+) (?:of a max of|out of maximum) (\d+) players online\.?:? ?(.*)$")


class Instance:
    def __init__(self, sid):
        self.id = sid
        self.dir = os.path.join(SERVERS_DIR, sid)
        self.meta_path = os.path.join(self.dir, "mcm.json")
        self.players_path = os.path.join(self.dir, "mcm_players.json")
        self.meta = read_json(self.meta_path, {}) or {}
        self.players = read_json(self.players_path, {}) or {}
        self.proc = None
        self.state = "stopped" if self.meta.get("launch") else "not_installed"
        self.online = {}           # name -> join time
        self.log = collections.deque(maxlen=2000)
        self.subs = set()
        self.waiters = []
        self.lock = threading.RLock()
        self.started_at = None
        self.max_players = None
        self._stop_requested = False
        self._seq = 0

    # ------------------------------------------------------------ 基本
    def save_meta(self):
        write_json(self.meta_path, self.meta)

    def save_players(self):
        write_json(self.players_path, self.players)

    def summary(self):
        return {
            "id": self.id, "name": self.meta.get("name", self.id), "type": self.meta.get("type"),
            "mc_version": self.meta.get("mc_version"), "loader_version": self.meta.get("loader_version"),
            "state": self.state, "port": self.get_props().get("server-port", ""),
            "online": sorted(self.online), "max_players": self.max_players,
            "java": self.meta.get("java"), "mem_min": self.meta.get("mem_min"), "mem_max": self.meta.get("mem_max"),
            "jvm_args": self.meta.get("jvm_args", ""), "autostart": self.meta.get("autostart", False),
            "discord_webhook": self.meta.get("discord_webhook", ""),
            "addon_dir": installer.TYPES.get(self.meta.get("type"), {}).get("addon_dir"),
            "started_at": self.started_at, "pid": self.proc.pid if self.proc else None,
        }

    # ------------------------------------------------------------ 主控台
    def emit(self, text, kind="log"):
        with self.lock:
            self._seq += 1
            item = {"seq": self._seq, "t": time.time(), "text": text, "kind": kind}
            self.log.append(item)
            dead = []
            for q in self.subs:
                try:
                    q.put_nowait(item)
                except queue.Full:
                    dead.append(q)
            for q in dead:
                self.subs.discard(q)

    def subscribe(self):
        q = queue.Queue(maxsize=5000)
        with self.lock:
            backlog = list(self.log)
            self.subs.add(q)
        return q, backlog

    def unsubscribe(self, q):
        with self.lock:
            self.subs.discard(q)

    def sys(self, msg):
        self.emit(msg, "sys")

    # ------------------------------------------------------------ server.properties
    @property
    def props_path(self):
        return os.path.join(self.dir, "server.properties")

    def get_props(self):
        props = {}
        try:
            with open(self.props_path, encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.rstrip("\r\n")
                    if not line or line.lstrip().startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    props[k.strip()] = v.replace("\\:", ":").replace("\\=", "=").replace("\\\\", "\\")
        except OSError:
            pass
        return props

    def set_props(self, updates):
        lines, seen = [], set()
        try:
            with open(self.props_path, encoding="utf-8", errors="replace") as f:
                for line in f:
                    raw = line.rstrip("\r\n")
                    if raw and not raw.lstrip().startswith("#") and "=" in raw:
                        k = raw.split("=", 1)[0].strip()
                        if k in updates:
                            raw = f"{k}={self._esc(updates[k])}"
                            seen.add(k)
                    lines.append(raw)
        except OSError:
            lines = ["#Minecraft server properties"]
        for k, v in updates.items():
            if k not in seen:
                lines.append(f"{k}={self._esc(v)}")
        with open(self.props_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    @staticmethod
    def _esc(v):
        return str(v).replace("\\", "\\\\").replace("\n", "\\n")

    @property
    def level_name(self):
        return self.get_props().get("level-name") or "world"

    # ------------------------------------------------------------ 安裝
    def install_async(self):
        def run():
            self.state = "installing"
            self.sys("=== 開始安裝 ===")
            try:
                launch = installer.install(self, self.sys)
                self.meta["launch"] = launch
                self.save_meta()
                self.state = "stopped"
                self.sys("=== 安裝完成，可以按「啟動」了 ===")
            except Exception as e:
                self.state = "not_installed"
                self.sys(f"!!! 安裝失敗：{e}")
                self.save_meta()
        threading.Thread(target=run, daemon=True).start()

    # ------------------------------------------------------------ 啟動/停止
    def build_cmd(self):
        launch = self.meta.get("launch")
        if not launch:
            raise RuntimeError("尚未安裝")
        java = javamod.ensure_java(self.meta.get("java") or 21, self.sys)
        cmd = [java, f"-Xms{self.meta.get('mem_min', '1G')}", f"-Xmx{self.meta.get('mem_max', '2G')}"]
        extra = (self.meta.get("jvm_args") or "").split()
        cmd += extra
        if launch["mode"] == "jar":
            cmd += ["-jar", launch["jar"], "nogui"]
        else:
            cmd += launch["args"] + ["nogui"]
        return cmd

    def start(self):
        with self.lock:
            if self.state in ("running", "starting", "stopping", "installing"):
                return
            if not self.meta.get("launch"):
                raise RuntimeError("伺服器尚未安裝完成")
            self.state = "starting"
        try:
            with open(os.path.join(self.dir, "eula.txt"), "w") as f:
                f.write("eula=true\n")
            cmd = self.build_cmd()
            self.sys("啟動：" + " ".join(cmd))
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = subprocess.CREATE_NO_WINDOW
            env = dict(os.environ)
            env.pop("JAVA_HOME", None); env.pop("JAVA_TOOL_OPTIONS", None); env.pop("_JAVA_OPTIONS", None)
            jhome = os.path.dirname(os.path.dirname(cmd[0]))
            env["JAVA_HOME"] = jhome  # 只對這個子程序有效，不會改到系統
            self.proc = subprocess.Popen(cmd, cwd=self.dir, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, env=env, **kw)
        except Exception as e:
            self.state = "stopped"
            self.sys(f"!!! 啟動失敗：{e}")
            raise
        self.started_at = time.time()
        self._stop_requested = False
        self.online.clear()
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()

    def _reader(self, proc):
        for raw in proc.stdout:
            line = ANSI.sub("", raw.decode("utf-8", "replace")).rstrip("\r\n")
            if not line:
                continue
            if self._check_waiters(line):
                continue
            self._parse(line)
            self.emit(line)
        code = proc.wait()
        self.online.clear()
        self.proc = None
        self.started_at = None
        crashed = not self._stop_requested and code != 0
        self.state = "stopped"
        self.sys(f"=== 伺服器已停止（代碼 {code}）{'— 異常結束！' if crashed else ''} ===")
        self.discord(f"🔴 **{self.meta.get('name')}** 已停止" + ("（異常結束）" if crashed else ""))

    def _parse(self, line):
        m = RE_UUID.search(line)
        if m:
            self._touch_player(m.group(1), uuid=m.group(2))
        m = RE_JOIN.search(line)
        if m:
            name = m.group(1)
            self.online[name] = time.time()
            self._touch_player(name)
            self.discord(f"➕ **{name}** 加入了 {self.meta.get('name')}")
            return
        m = RE_LEFT.search(line)
        if m:
            name = m.group(1)
            self.online.pop(name, None)
            self._touch_player(name)
            self.discord(f"➖ **{name}** 離開了 {self.meta.get('name')}")
            return
        m = RE_CHAT.search(line)
        if m:
            self.discord(f"💬 **{m.group(1)}**: {m.group(2)}")
            return
        if self.state == "starting" and RE_DONE.search(line):
            self.state = "running"
            self.discord(f"🟢 **{self.meta.get('name')}** 已啟動")
            threading.Thread(target=self.refresh_list, daemon=True).start()

    def _touch_player(self, name, uuid=None):
        key = name.lower()
        p = self.players.setdefault(key, {"name": name, "note": "", "first_seen": time.time()})
        p["name"] = name
        p["last_seen"] = time.time()
        if uuid:
            p["uuid"] = uuid
        self.save_players()

    def send(self, cmd):
        if not self.proc or not self.proc.stdin:
            raise RuntimeError("伺服器未在運行")
        cmd = cmd.lstrip("/")
        self.proc.stdin.write((cmd + "\n").encode("utf-8"))
        self.proc.stdin.flush()

    def stop(self, wait=False, timeout=90):
        p = self.proc
        if not p:
            return
        self._stop_requested = True
        self.state = "stopping"
        self.sys("送出 stop 指令…")
        try:
            self.send("stop")
        except Exception:
            pass

        def guard():
            try:
                p.wait(timeout)
            except subprocess.TimeoutExpired:
                self.sys("關閉逾時，強制結束程序")
                p.kill()
        if wait:
            guard()
        else:
            threading.Thread(target=guard, daemon=True).start()

    def kill(self):
        if self.proc:
            self._stop_requested = True
            self.sys("強制結束程序！（未存檔的進度可能遺失）")
            self.proc.kill()

    def restart(self):
        def run():
            p = self.proc
            if p:
                self.stop(wait=True)
                while self.proc is not None:
                    time.sleep(0.2)
            self.start()
        threading.Thread(target=run, daemon=True).start()

    # ------------------------------------------------------------ 指令回應擷取（不顯示在主控台）
    def _check_waiters(self, line):
        with self.lock:
            for w in self.waiters:
                if not w["done"]:
                    m = w["re"].search(line)
                    if m:
                        w["match"] = m
                        w["done"] = True
                        w["ev"].set()
                        return True
        return False

    def query(self, cmd, pattern, timeout=2.5):
        if self.state != "running":
            return None
        w = {"re": re.compile(pattern), "ev": threading.Event(), "done": False, "match": None}
        with self.lock:
            self.waiters.append(w)
        try:
            self.send(cmd)
            w["ev"].wait(timeout)
            return w["match"]
        finally:
            with self.lock:
                w["done"] = True
                self.waiters.remove(w)

    def refresh_list(self):
        m = self.query("list", RE_LIST.pattern)
        if m:
            self.max_players = int(m.group(2))
            names = [n.strip() for n in m.group(3).split(",") if n.strip()]
            names = [re.sub(r"\s*\(.*\)$", "", n) for n in names]
            if int(m.group(1)) > 0 and not names:  # Paper 會把名單印在下一行，改用加入/離開紀錄
                return
            now = time.time()
            self.online = {n: self.online.get(n, now) for n in names}
            for n in names:
                self._touch_player(n)

    def live_positions(self):
        out = []
        for name in list(self.online):
            n = re.escape(name)
            m = self.query(f"data get entity {name} Pos",
                           n + r" has the following entity data: \[(-?[\d.E-]+)d, (-?[\d.E-]+)d, (-?[\d.E-]+)d\]|No entity was found")
            if not m or m.group(1) is None:
                continue
            d = self.query(f"data get entity {name} Dimension",
                           n + r' has the following entity data: "([^"]+)"|No entity was found')
            out.append({"name": name, "x": float(m.group(1)), "y": float(m.group(2)), "z": float(m.group(3)),
                        "dim": d.group(1) if d and d.group(1) else "minecraft:overworld", "online": True})
        return out

    # ------------------------------------------------------------ Discord（預留：Webhook 推播）
    def discord(self, text):
        url = (self.meta.get("discord_webhook") or "").strip()
        if not url.startswith("https://"):
            return

        def post():
            try:
                req = urllib.request.Request(url, data=json.dumps({"content": text[:1900]}).encode(),
                                             headers={"Content-Type": "application/json",
                                                      "User-Agent": "MCWebManager/1.0"})
                urllib.request.urlopen(req, timeout=10).read()
            except Exception:
                pass
        threading.Thread(target=post, daemon=True).start()

    # ------------------------------------------------------------ 玩家列表
    def player_list(self):
        cache = read_json(os.path.join(self.dir, "usercache.json"), []) or []
        for e in cache:
            n = e.get("name")
            if n and n.lower() not in self.players:
                self.players[n.lower()] = {"name": n, "note": "", "uuid": e.get("uuid")}
            elif n and not self.players[n.lower()].get("uuid"):
                self.players[n.lower()]["uuid"] = e.get("uuid")
        ops = {e.get("name", "").lower() for e in read_json(os.path.join(self.dir, "ops.json"), []) or []}
        banned = {e.get("name", "").lower() for e in read_json(os.path.join(self.dir, "banned-players.json"), []) or []}
        online_l = {n.lower() for n in self.online}
        out = []
        for key, p in self.players.items():
            out.append(dict(p, online=key in online_l, op=key in ops, banned=key in banned))
        out.sort(key=lambda p: (not p["online"], -(p.get("last_seen") or 0)))
        return out


# ---------------------------------------------------------------- 實例管理
class Manager:
    def __init__(self):
        self.instances = {}
        for sid in sorted(os.listdir(SERVERS_DIR)):
            if os.path.exists(os.path.join(SERVERS_DIR, sid, "mcm.json")):
                self.instances[sid] = Instance(sid)

    def get(self, sid):
        inst = self.instances.get(sid)
        if not inst:
            raise KeyError("找不到伺服器")
        return inst

    def used_ports(self):
        ports = set()
        for i in self.instances.values():
            try:
                ports.add(int(i.get_props().get("server-port") or i.meta.get("port") or 0))
            except ValueError:
                pass
        return ports

    def next_port(self):
        used = self.used_ports()
        p = 25565
        while p in used:
            p += 1
        return p

    def create(self, body):
        stype = body.get("type")
        if stype not in installer.TYPES:
            raise ValueError("未知的伺服器類型")
        if not body.get("eula"):
            raise ValueError("必須同意 Minecraft EULA")
        mc = body.get("mc_version")
        if not mc:
            raise ValueError("請選擇版本")
        port = int(body.get("port") or self.next_port())
        if port in self.used_ports():
            raise ValueError(f"連接埠 {port} 已被其他伺服器使用")
        sid = uuidlib.uuid4().hex[:8]
        d = os.path.join(SERVERS_DIR, sid)
        os.makedirs(d)
        inst = Instance(sid)
        inst.meta = {
            "name": (body.get("name") or f"{stype} {mc}").strip()[:60], "type": stype, "mc_version": mc,
            "loader_version": body.get("loader_version") or "", "mem_min": body.get("mem_min") or "1G",
            "mem_max": body.get("mem_max") or "4G", "jvm_args": "", "autostart": False, "created": time.time(),
            "port": port, "discord_webhook": "",
        }
        inst.save_meta()
        inst.set_props({"server-port": port, "motd": inst.meta["name"], "enable-command-block": "false"})
        self.instances[sid] = inst
        inst.install_async()
        return inst

    def delete(self, sid):
        inst = self.get(sid)
        if inst.proc:
            raise RuntimeError("請先停止伺服器")
        if inst.state == "installing":
            raise RuntimeError("安裝中，無法刪除")
        del self.instances[sid]
        shutil.rmtree(inst.dir, ignore_errors=True)

    def stop_all(self):
        threads = []
        for inst in self.instances.values():
            if inst.proc:
                t = threading.Thread(target=inst.stop, kwargs={"wait": True})
                t.start()
                threads.append(t)
        for t in threads:
            t.join()
