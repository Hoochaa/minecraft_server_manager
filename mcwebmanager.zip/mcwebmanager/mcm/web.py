"""HTTP 伺服器與 REST API（只用 Python 標準函式庫）。"""
import base64
import json
import mimetypes
import os
import queue
import re
import shutil
import tempfile
import threading
import time
import traceback
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import installer, java as javamod, mapper
from .instance import Manager
from .util import CONFIG, WEB_DIR, CACHE_DIR, safe_join

MANAGER = None
HTTPD = None
_render_sem = threading.Semaphore(2)


class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


def _clean_name(name, default="file"):
    name = os.path.basename(name.replace("\\", "/"))
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).strip(". ")
    return name or default


def _dir_size(p):
    total = 0
    for dp, _d, files in os.walk(p):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return total


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MCWebManager/1.0"

    def log_message(self, fmt, *args):
        pass

    # ------------------------------------------------------------ 共用
    def _auth_ok(self):
        pw = CONFIG.get("password") or ""
        if not pw:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                user_pw = base64.b64decode(h[6:]).decode("utf-8")
                if user_pw.split(":", 1)[-1] == pw:
                    return True
            except Exception:
                pass
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="MC Web Manager"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, extra=None):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, ctype=None, download_name=None):
        size = os.path.getsize(path)
        self.send_response(200)
        self.send_header("Content-Type", ctype or mimetypes.guess_type(path)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(size))
        if download_name:
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(download_name))
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile, 1 << 16)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def save_body(self, dest):
        n = int(self.headers.get("Content-Length") or 0)
        tmp = dest + ".uploading"
        with open(tmp, "wb") as f:
            left = n
            while left > 0:
                chunk = self.rfile.read(min(left, 1 << 20))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        if left > 0:
            os.remove(tmp)
            raise ApiError("上傳中斷")
        os.replace(tmp, dest)

    # ------------------------------------------------------------ 分派
    def do_GET(self): self._dispatch("GET")
    def do_POST(self): self._dispatch("POST")
    def do_PUT(self): self._dispatch("PUT")
    def do_DELETE(self): self._dispatch("DELETE")

    def _dispatch(self, method):
        if not self._auth_ok():
            return
        u = urllib.parse.urlparse(self.path)
        self.q = {k: v[-1] for k, v in urllib.parse.parse_qs(u.query).items()}
        path = u.path
        try:
            if not path.startswith("/api/"):
                if method != "GET":
                    raise ApiError("Not found", 404)
                return self.static(path)
            parts = [urllib.parse.unquote(p) for p in path[5:].strip("/").split("/")]
            fn = getattr(self, f"api_{method}_{parts[0]}", None)
            if not fn:
                raise ApiError("Not found", 404)
            return fn(parts[1:])
        except ApiError as e:
            self._try_err(str(e), e.code)
        except (KeyError, ValueError, RuntimeError) as e:
            self._try_err(str(e).strip("'\""), 400)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except PermissionError:
            self._try_err("檔案正在被使用中，請先停止伺服器再操作", 409)
        except Exception as e:
            traceback.print_exc()
            self._try_err(f"伺服器錯誤：{e}", 500)

    def _try_err(self, msg, code):
        try:
            # 確保沒讀完的上傳內容不會卡住連線
            self.close_connection = True
            self.send_json({"error": msg}, code)
        except Exception:
            pass

    def static(self, path):
        if path in ("", "/"):
            path = "/index.html"
        p = safe_join(WEB_DIR, path.lstrip("/"))
        if not os.path.isfile(p):
            raise ApiError("Not found", 404)
        self.send_file(p)

    # ------------------------------------------------------------ 全域 API
    def api_GET_meta(self, _):
        self.send_json({"types": installer.TYPES, "java": javamod.installed(), "next_port": MANAGER.next_port(),
                        "password": bool(CONFIG.get("password"))})

    def api_GET_versions(self, _):
        t = self.q.get("type", "vanilla")
        try:
            self.send_json({"versions": installer.game_versions(t, self.q.get("snapshots") == "1")})
        except Exception as e:
            raise ApiError(f"無法取得版本清單（請確認電腦可以連上網路）：{e}", 502)

    def api_GET_loaders(self, _):
        try:
            self.send_json({"versions": installer.loader_versions(self.q.get("type"), self.q.get("mc"))})
        except Exception as e:
            raise ApiError(f"無法取得載入器版本：{e}", 502)

    def api_POST_shutdown(self, _):
        self.send_json({"ok": True})

        def bye():
            print("收到網頁關閉指令：正在停止所有 Minecraft 伺服器…")
            MANAGER.stop_all()
            print("全部停止，管理程式結束。")
            HTTPD.shutdown()
        threading.Thread(target=bye, daemon=True).start()

    # ------------------------------------------------------------ 伺服器 API
    def api_GET_servers(self, p):
        if not p:
            return self.send_json({"servers": [i.summary() for i in MANAGER.instances.values()]})
        inst = MANAGER.get(p[0])
        sub = p[1] if len(p) > 1 else ""
        if sub == "":
            return self.send_json(inst.summary())
        if sub == "console":
            return self.sse(inst)
        if sub == "properties":
            return self.send_json({"properties": inst.get_props(), "running": bool(inst.proc)})
        if sub == "players":
            return self.send_json({"players": inst.player_list()})
        if sub == "files":
            return self.list_files(inst, self.q.get("dir", ""))
        if sub == "worlds":
            return self.list_worlds(inst)
        if sub == "download":
            return self.download_world(inst, self.q.get("world", ""))
        if sub == "map":
            return self.map_api(inst, p[2] if len(p) > 2 else "")
        raise ApiError("Not found", 404)

    def api_POST_servers(self, p):
        if not p:
            inst = MANAGER.create(self.body_json())
            return self.send_json(inst.summary())
        inst = MANAGER.get(p[0])
        action = p[1] if len(p) > 1 else ""
        if action == "start":
            inst.start()
        elif action == "stop":
            inst.stop()
        elif action == "restart":
            inst.restart()
        elif action == "kill":
            inst.kill()
        elif action == "save":
            inst.send("save-all flush")
            inst.sys("已送出 save-all（存檔）")
        elif action == "reinstall":
            if inst.proc:
                raise ApiError("請先停止伺服器")
            inst.install_async()
        elif action == "command":
            text = (self.body_json().get("command") or "").strip()
            if not text:
                raise ApiError("指令是空的")
            if text.startswith("/"):
                cmd = text[1:]
            else:
                cmd = "say " + text
            inst.emit("> /" + cmd, "input")
            inst.send(cmd)
        elif action == "upload":
            return self.upload(inst)
        elif action == "worlds":
            return self.world_action(inst, self.body_json())
        elif action == "toggle":
            return self.toggle_file(inst, self.body_json().get("path", ""))
        else:
            raise ApiError("Not found", 404)
        self.send_json({"ok": True, "state": inst.state})

    def api_PUT_servers(self, p):
        inst = MANAGER.get(p[0])
        sub = p[1] if len(p) > 1 else ""
        body = self.body_json()
        if sub == "properties":
            props = {str(k): str(v) for k, v in (body.get("properties") or {}).items()}
            if "server-port" in props:
                port = int(props["server-port"])
                others = {int(i.get_props().get("server-port") or 0) for i in MANAGER.instances.values() if i is not inst}
                if port in others:
                    raise ApiError(f"連接埠 {port} 已被其他伺服器使用")
            inst.set_props(props)
            return self.send_json({"ok": True, "restart_needed": bool(inst.proc)})
        if sub == "players":
            name = p[2].lower()
            pl = inst.players.setdefault(name, {"name": p[2], "note": ""})
            pl["note"] = str(body.get("note", ""))[:100]
            inst.save_players()
            return self.send_json({"ok": True})
        if sub == "":
            for k in ("name", "mem_min", "mem_max", "jvm_args", "autostart", "discord_webhook"):
                if k in body:
                    inst.meta[k] = body[k]
            if body.get("java"):
                inst.meta["java"] = int(body["java"])
            for k in ("mem_min", "mem_max"):
                if not re.fullmatch(r"\d+[MG]", str(inst.meta.get(k, "")), re.I):
                    raise ApiError("記憶體格式要像 2G 或 1024M")
            inst.save_meta()
            return self.send_json(inst.summary())
        raise ApiError("Not found", 404)

    def api_DELETE_servers(self, p):
        if len(p) == 1:
            MANAGER.delete(p[0])
            return self.send_json({"ok": True})
        inst = MANAGER.get(p[0])
        if p[1] == "files":
            return self.delete_file(inst, self.q.get("path", ""))
        if p[1] == "players":
            inst.players.pop(p[2].lower(), None)
            inst.save_players()
            return self.send_json({"ok": True})
        raise ApiError("Not found", 404)

    # ------------------------------------------------------------ 主控台 SSE
    def sse(self, inst):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        q, backlog = inst.subscribe()
        try:
            for item in backlog[-800:]:
                self.wfile.write(b"data: " + json.dumps(item, ensure_ascii=False).encode() + b"\n\n")
            self.wfile.flush()
            while True:
                try:
                    item = q.get(timeout=15)
                    self.wfile.write(b"data: " + json.dumps(item, ensure_ascii=False).encode() + b"\n\n")
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            inst.unsubscribe(q)

    # ------------------------------------------------------------ 檔案（模組/插件/資料包）
    ALLOWED_DIRS = ("mods", "plugins", "config")

    def _area(self, inst, d):
        """mods / plugins / config / datapacks 才允許操作。"""
        if d == "datapacks":
            return os.path.join(inst.dir, inst.level_name, "datapacks")
        if d in self.ALLOWED_DIRS:
            return os.path.join(inst.dir, d)
        raise ApiError("不允許的資料夾")

    def list_files(self, inst, d):
        base = self._area(inst, d)
        out = []
        if os.path.isdir(base):
            for name in sorted(os.listdir(base), key=str.lower):
                fp = os.path.join(base, name)
                out.append({"name": name, "dir": os.path.isdir(fp), "size": os.path.getsize(fp) if os.path.isfile(fp) else 0,
                            "mtime": os.path.getmtime(fp), "disabled": name.endswith(".disabled")})
        self.send_json({"files": out})

    def toggle_file(self, inst, rel):
        d, _, name = rel.partition("/")
        base = self._area(inst, d)
        fp = safe_join(base, name)
        new = fp[:-9] if fp.endswith(".disabled") else fp + ".disabled"
        os.replace(fp, new)
        self.send_json({"ok": True, "restart_needed": bool(inst.proc)})

    def delete_file(self, inst, rel):
        d, _, name = rel.partition("/")
        if d == "world":
            if inst.proc:
                raise ApiError("請先停止伺服器再刪除世界")
            if name == inst.level_name:
                raise ApiError("不能刪除目前使用中的世界，請先切換")
            wp = safe_join(inst.dir, _clean_name(name))
            if not os.path.exists(os.path.join(wp, "level.dat")):
                raise ApiError("這不是世界資料夾")
            shutil.rmtree(wp)
            return self.send_json({"ok": True})
        fp = safe_join(self._area(inst, d), name)
        if os.path.isdir(fp):
            shutil.rmtree(fp)
        else:
            os.remove(fp)
        self.send_json({"ok": True, "restart_needed": bool(inst.proc)})

    def upload(self, inst):
        kind = self.q.get("kind", "addon")
        name = _clean_name(self.q.get("name", "upload.bin"))
        low = name.lower()
        if kind in ("mods", "plugins", "config", "datapacks"):
            base = self._area(inst, kind)
            os.makedirs(base, exist_ok=True)
            if kind in ("mods", "plugins") and low.endswith(".zip"):
                # 一次上傳多個模組：zip 裡的 .jar 會全部解出來
                tmp = os.path.join(CACHE_DIR, f"up_{time.time_ns()}.zip")
                self.save_body(tmp)
                count = 0
                try:
                    with zipfile.ZipFile(tmp) as z:
                        for info in z.infolist():
                            if info.filename.lower().endswith(".jar") and not info.is_dir():
                                with z.open(info) as src, open(os.path.join(base, _clean_name(info.filename)), "wb") as dst:
                                    shutil.copyfileobj(src, dst)
                                count += 1
                finally:
                    os.remove(tmp)
                return self.send_json({"ok": True, "message": f"已從 zip 解出 {count} 個 .jar", "restart_needed": bool(inst.proc)})
            if kind in ("mods", "plugins") and not low.endswith(".jar"):
                raise ApiError("模組/插件請上傳 .jar（或包含多個 .jar 的 .zip）")
            self.save_body(os.path.join(base, name))
            return self.send_json({"ok": True, "message": f"已上傳 {name}", "restart_needed": bool(inst.proc)})
        if kind == "world":
            if not low.endswith(".zip"):
                raise ApiError("地圖請壓縮成 .zip 上傳（裡面要有 level.dat）")
            tmpdir = tempfile.mkdtemp(dir=CACHE_DIR)
            try:
                zp = os.path.join(tmpdir, "w.zip")
                self.save_body(zp)
                ex = os.path.join(tmpdir, "x")
                with zipfile.ZipFile(zp) as z:
                    for info in z.infolist():
                        target = safe_join(ex, info.filename)  # 防止 zip slip
                        if info.is_dir():
                            os.makedirs(target, exist_ok=True)
                        else:
                            os.makedirs(os.path.dirname(target), exist_ok=True)
                            with z.open(info) as src, open(target, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                root = None
                for dp, dirs, files in os.walk(ex):
                    if "level.dat" in files:
                        root = dp
                        break
                if not root:
                    raise ApiError("zip 裡找不到 level.dat，這不是 Minecraft 世界")
                wname = _clean_name(self.q.get("world") or os.path.splitext(name)[0], "world")
                wname = re.sub(r"\s+", "_", wname)
                final, n = wname, 2
                while os.path.exists(os.path.join(inst.dir, final)):
                    final = f"{wname}_{n}"
                    n += 1
                shutil.move(root, os.path.join(inst.dir, final))
            finally:
                shutil.rmtree(tmpdir, ignore_errors=True)
            if self.q.get("activate") == "1" and not inst.proc:
                inst.set_props({"level-name": final})
            return self.send_json({"ok": True, "message": f"世界已匯入為「{final}」", "world": final})
        raise ApiError("未知的上傳類型")

    def list_worlds(self, inst):
        active = inst.level_name
        out = []
        for name in sorted(os.listdir(inst.dir)):
            wp = os.path.join(inst.dir, name)
            if os.path.isdir(wp) and os.path.exists(os.path.join(wp, "level.dat")):
                out.append({"name": name, "active": name == active, "size": _dir_size(wp),
                            "mtime": os.path.getmtime(os.path.join(wp, "level.dat"))})
        self.send_json({"worlds": out, "active": active, "running": bool(inst.proc)})

    def world_action(self, inst, body):
        name = _clean_name(body.get("name", ""))
        if body.get("action") == "activate":
            if inst.proc:
                raise ApiError("請先停止伺服器再切換世界")
            if not os.path.exists(os.path.join(inst.dir, name, "level.dat")):
                raise ApiError("找不到這個世界")
            inst.set_props({"level-name": name})
            return self.send_json({"ok": True})
        raise ApiError("未知的動作")

    def download_world(self, inst, world):
        world = _clean_name(world)
        wp = safe_join(inst.dir, world)
        if not os.path.exists(os.path.join(wp, "level.dat")):
            raise ApiError("找不到這個世界")
        if inst.proc:
            try:
                inst.send("save-all flush")
                time.sleep(2)
            except Exception:
                pass
        tmp = os.path.join(CACHE_DIR, f"dl_{time.time_ns()}.zip")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
                for dp, _d, files in os.walk(wp):
                    for f in files:
                        if f == "session.lock":
                            continue
                        fp = os.path.join(dp, f)
                        try:
                            z.write(fp, os.path.relpath(fp, inst.dir))
                        except OSError:
                            pass
            self.send_file(tmp, "application/zip", f"{world}.zip")
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    # ------------------------------------------------------------ 地圖
    def map_api(self, inst, what):
        level = inst.level_name
        if what == "dims":
            dims = mapper.find_dimensions(inst.dir, level)
            spawn = None
            try:
                ld = mapper.read_nbt_file(os.path.join(inst.dir, level, "level.dat")).get("Data", {})
                if "SpawnX" in ld:
                    spawn = [ld.get("SpawnX", 0), ld.get("SpawnZ", 0)]
                elif isinstance(ld.get("spawn"), dict) and "pos" in ld["spawn"]:
                    pos = ld["spawn"]["pos"]
                    spawn = [pos[0], pos[2]]
            except Exception:
                pass
            out = []
            for key, v in dims.items():
                out.append({"key": key, "dim": v["dim"], "regions": mapper.list_regions(v["path"])})
            out.sort(key=lambda d: (d["dim"] != "minecraft:overworld", d["key"]))
            return self.send_json({"dims": out, "spawn": spawn})
        if what == "tile":
            key = self.q.get("key", "")
            x, z = int(self.q.get("x", 0)), int(self.q.get("z", 0))
            region_dir = safe_join(inst.dir, key)
            if os.path.basename(region_dir) != "region":
                raise ApiError("bad key")
            mca = os.path.join(region_dir, f"r.{x}.{z}.mca")
            if not os.path.exists(mca):
                raise ApiError("Not found", 404)
            cache = os.path.join(inst.dir, ".mcm_cache", "map", re.sub(r"[^A-Za-z0-9_]", "_", key), f"{x}.{z}.png")
            if not (os.path.exists(cache) and os.path.getmtime(cache) >= os.path.getmtime(mca)):
                with _render_sem:
                    if not (os.path.exists(cache) and os.path.getmtime(cache) >= os.path.getmtime(mca)):
                        png = mapper.render_region(mca, overworld=mapper.dim_id_from_path(key) == "minecraft:overworld"
                                                   and "_nether" not in key and "_the_end" not in key)
                        os.makedirs(os.path.dirname(cache), exist_ok=True)
                        with open(cache, "wb") as f:
                            f.write(png)
            return self.send_file(cache, "image/png")
        if what == "players":
            online = inst.live_positions() if inst.state == "running" else []
            on_names = {p["name"].lower() for p in online} | {n.lower() for n in inst.online}
            offline = [p for p in mapper.offline_positions(inst.dir, level) if p["name"].lower() not in on_names]
            notes = {k: v.get("note", "") for k, v in inst.players.items()}
            for p in online + offline:
                p["note"] = notes.get(p["name"].lower(), "")
            return self.send_json({"online": online, "offline": offline})
        raise ApiError("Not found", 404)


def serve():
    global MANAGER, HTTPD
    MANAGER = Manager()
    for inst in MANAGER.instances.values():
        if inst.meta.get("autostart") and inst.meta.get("launch"):
            try:
                inst.start()
            except Exception as e:
                print(f"自動啟動 {inst.meta.get('name')} 失敗：{e}")
    ThreadingHTTPServer.daemon_threads = True
    ThreadingHTTPServer.allow_reuse_address = True
    HTTPD = _bind_server()
    return MANAGER, HTTPD


def _bind_server():
    """綁定連接埠；若被 Windows 保留或占用（WinError 10013/10048），自動換下一個並記到設定檔。"""
    from .util import CONFIG_PATH, write_json
    want = int(CONFIG.get("port") or 8080)
    candidates = [want] + [p for p in list(range(8080, 8100)) + [8123, 8888, 18080, 28080, 38080, 48080] if p != want]
    last = None
    for port in candidates:
        try:
            httpd = ThreadingHTTPServer((CONFIG["host"], port), Handler)
        except OSError as e:
            last = e
            print(f"連接埠 {port} 無法使用（{e.strerror or e}），嘗試下一個…")
            continue
        if port != want:
            CONFIG["port"] = port
            try:
                write_json(CONFIG_PATH, CONFIG)
                print(f"已改用連接埠 {port}，並寫入 data/config.json")
            except OSError:
                pass
        return httpd
    raise SystemExit(f"找不到可用的連接埠：{last}\n請在 data/config.json 把 port 改成其他數字（例如 18080）")
