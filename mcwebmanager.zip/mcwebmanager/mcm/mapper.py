"""讀取 Minecraft 存檔（Anvil .mca / NBT），繪製俯視地形圖與玩家位置。

支援 1.13 以上的存檔格式（1.18+ 完整支援 -64 高度）。
地形只在伺服器存檔後才會更新（按「存檔」=save-all 就會寫入硬碟）。
"""
import gzip
import os
import struct
import zlib

from .util import read_json

M64 = (1 << 64) - 1


# ---------------------------------------------------------------- NBT
class _R:
    __slots__ = ("b", "i")

    def __init__(self, b):
        self.b, self.i = b, 0

    def take(self, n):
        s = self.b[self.i:self.i + n]
        self.i += n
        return s

    def fmt(self, f, n):
        v = struct.unpack_from(f, self.b, self.i)
        self.i += n
        return v[0]


def _payload(r, t):
    if t == 1: return r.fmt(">b", 1)
    if t == 2: return r.fmt(">h", 2)
    if t == 3: return r.fmt(">i", 4)
    if t == 4: return r.fmt(">q", 8)
    if t == 5: return r.fmt(">f", 4)
    if t == 6: return r.fmt(">d", 8)
    if t == 7:
        n = r.fmt(">i", 4); return r.take(n)
    if t == 8:
        n = r.fmt(">H", 2); return r.take(n).decode("utf-8", "replace")
    if t == 9:
        et = r.fmt(">b", 1); n = r.fmt(">i", 4)
        if et in (1, 2, 3, 4, 5, 6) and n > 0:
            f = {1: "b", 2: "h", 3: "i", 4: "q", 5: "f", 6: "d"}[et]
            size = struct.calcsize(f)
            v = list(struct.unpack_from(f">{n}{f}", r.b, r.i)); r.i += size * n
            return v
        return [_payload(r, et) for _ in range(max(n, 0))]
    if t == 10:
        out = {}
        while True:
            tt = r.fmt(">b", 1)
            if tt == 0:
                return out
            n = r.fmt(">H", 2)
            name = r.take(n).decode("utf-8", "replace")
            out[name] = _payload(r, tt)
    if t == 11:
        n = r.fmt(">i", 4); v = struct.unpack_from(f">{n}i", r.b, r.i); r.i += 4 * n; return v
    if t == 12:
        n = r.fmt(">i", 4); v = struct.unpack_from(f">{n}q", r.b, r.i); r.i += 8 * n; return v
    raise ValueError(f"未知的 NBT tag {t}")


def parse_nbt(data):
    r = _R(data)
    t = r.fmt(">b", 1)
    n = r.fmt(">H", 2)
    r.take(n)
    return _payload(r, t)


def read_nbt_file(path):
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return parse_nbt(raw)


# ---------------------------------------------------------------- 方塊顏色
COLORS = {
    "grass_block": (92, 148, 60), "short_grass": (88, 140, 56), "grass": (88, 140, 56), "tall_grass": (88, 140, 56),
    "fern": (80, 130, 52), "large_fern": (80, 130, 52), "dirt": (134, 96, 67), "coarse_dirt": (119, 85, 59),
    "podzol": (106, 76, 40), "mycelium": (111, 99, 105), "rooted_dirt": (144, 103, 76), "mud": (60, 57, 60),
    "dirt_path": (148, 122, 65), "farmland": (110, 75, 45), "stone": (125, 125, 125), "cobblestone": (122, 122, 122),
    "deepslate": (80, 80, 82), "andesite": (136, 136, 136), "diorite": (188, 188, 188), "granite": (149, 103, 85),
    "tuff": (108, 109, 102), "calcite": (223, 224, 220), "gravel": (131, 127, 126), "sand": (219, 207, 163),
    "red_sand": (190, 102, 33), "sandstone": (216, 203, 155), "red_sandstone": (186, 99, 29), "clay": (160, 166, 179),
    "water": (52, 92, 196), "bubble_column": (52, 92, 196), "kelp": (52, 100, 160), "kelp_plant": (52, 100, 160),
    "seagrass": (52, 100, 170), "tall_seagrass": (52, 100, 170), "lava": (207, 92, 20), "ice": (145, 183, 253),
    "packed_ice": (141, 180, 250), "blue_ice": (116, 167, 253), "snow": (248, 250, 250), "snow_block": (248, 250, 250),
    "powder_snow": (248, 250, 250), "terracotta": (152, 94, 67), "netherrack": (111, 54, 52),
    "soul_sand": (81, 62, 50), "soul_soil": (75, 57, 46), "basalt": (80, 81, 86), "blackstone": (42, 36, 41),
    "crimson_nylium": (130, 31, 31), "warped_nylium": (43, 114, 101), "nether_wart_block": (114, 2, 2),
    "warped_wart_block": (22, 119, 121), "glowstone": (171, 131, 84), "magma_block": (142, 63, 31),
    "end_stone": (219, 222, 158), "obsidian": (15, 10, 24), "bedrock": (85, 85, 85), "moss_block": (89, 109, 45),
    "lily_pad": (32, 128, 48), "cactus": (85, 127, 43), "sugar_cane": (148, 192, 101), "bamboo": (93, 144, 19),
    "pumpkin": (198, 118, 24), "melon": (111, 145, 30), "hay_block": (166, 136, 38), "chorus_plant": (93, 57, 93),
    "purpur_block": (169, 125, 169), "mangrove_roots": (74, 59, 38), "cherry_leaves": (229, 172, 194),
    "azalea_leaves": (90, 115, 44), "flowering_azalea_leaves": (100, 111, 60), "pale_moss_block": (106, 112, 104),
}
KEYWORDS = [
    ("leaves", (60, 110, 40)), ("log", (102, 81, 50)), ("wood", (102, 81, 50)), ("stem", (90, 50, 70)),
    ("planks", (162, 130, 78)), ("slab", (150, 140, 120)), ("stairs", (150, 140, 120)), ("wool", (220, 220, 220)),
    ("concrete", (180, 180, 180)), ("terracotta", (150, 90, 70)), ("glass", (200, 220, 230)), ("ore", (120, 120, 120)),
    ("stone", (125, 125, 125)), ("brick", (150, 97, 83)), ("flower", (200, 80, 80)), ("tulip", (200, 80, 80)),
    ("rose", (190, 40, 40)), ("mushroom", (160, 120, 100)), ("coral", (200, 80, 150)), ("ice", (145, 183, 253)),
    ("snow", (248, 250, 250)), ("sand", (219, 207, 163)), ("copper", (192, 107, 79)), ("wheat", (180, 170, 60)),
    ("carrots", (100, 150, 50)), ("potatoes", (100, 150, 50)), ("vine", (60, 110, 40)), ("bush", (70, 120, 40)),
]
_color_cache = {}


def block_color(name):
    c = _color_cache.get(name)
    if c:
        return c
    short = name.split(":", 1)[-1]
    c = COLORS.get(short)
    if not c:
        for kw, col in KEYWORDS:
            if kw in short:
                c = col
                break
    if not c:
        h = zlib.crc32(short.encode()) & 0xFFFFFF
        c = (90 + (h & 63), 90 + ((h >> 6) & 63), 90 + ((h >> 12) & 63))
    _color_cache[name] = c
    return c


# ---------------------------------------------------------------- 位元解包
def packed_get(longs, bits, idx, spanning):
    mask = (1 << bits) - 1
    if not spanning:
        per = 64 // bits
        li = idx // per
        if li >= len(longs):
            return 0
        return ((longs[li] & M64) >> ((idx % per) * bits)) & mask
    bitpos = idx * bits
    li, off = bitpos >> 6, bitpos & 63
    if li >= len(longs):
        return 0
    v = (longs[li] & M64) >> off
    if off + bits > 64 and li + 1 < len(longs):
        v |= (longs[li + 1] & M64) << (64 - off)
    return v & mask


def _heightmap_bits(n_longs, spanning):
    if spanning:
        return 9
    for bits in range(9, 13):
        if -(-256 // (64 // bits)) == n_longs:
            return bits
    return 9


# ---------------------------------------------------------------- 區塊 → 頂面
def chunk_surface(chunk, overworld):
    """回傳 256 個 (顏色, 高度) 或 None（不支援的格式）。"""
    dv = chunk.get("DataVersion", 0)
    level = chunk.get("Level", chunk)
    status = level.get("Status", "")
    if isinstance(status, str) and status and status.split(":")[-1] not in ("full", "postprocessed", "spawn", "heightmaps", "light", "features"):
        return None
    hm = (level.get("Heightmaps") or {}).get("WORLD_SURFACE")
    if not hm:
        return None
    spanning = dv < 2527  # 1.16 之前位元會跨 long
    hbits = _heightmap_bits(len(hm), spanning)

    sections = {}
    if "sections" in level:  # 1.18+
        for s in level["sections"]:
            bs = s.get("block_states")
            if bs and "palette" in bs:
                sections[s["Y"]] = (bs["palette"], bs.get("data"))
    else:  # 1.13–1.17
        for s in level.get("Sections", []):
            if "Palette" in s:
                sections[s["Y"]] = (s["Palette"], s.get("BlockStates"))
    min_y = -64 if (overworld and dv >= 2860) else 0

    out = []
    for i in range(256):
        h = packed_get(hm, hbits, i, spanning)
        if h == 0:
            out.append(None)
            continue
        y = h - 1 + min_y
        sec = sections.get(y >> 4)
        name = "minecraft:air"
        if sec:
            palette, data = sec
            if len(palette) == 1 or not data:
                name = palette[0].get("Name", "minecraft:air")
            else:
                bits = max(4, (len(palette) - 1).bit_length())
                idx = ((y & 15) << 8) | i  # i = z*16 + x
                pi = packed_get(data, bits, idx, spanning)
                if pi < len(palette):
                    name = palette[pi].get("Name", "minecraft:air")
        out.append((block_color(name), y))
    return out


def iter_region_chunks(path):
    with open(path, "rb") as f:
        buf = f.read()
    if len(buf) < 8192:
        return
    for idx in range(1024):
        off = int.from_bytes(buf[idx * 4:idx * 4 + 3], "big")
        if off == 0:
            continue
        pos = off * 4096
        if pos + 5 > len(buf):
            continue
        length = int.from_bytes(buf[pos:pos + 4], "big")
        comp = buf[pos + 4]
        raw = buf[pos + 5:pos + 4 + length]
        try:
            if comp == 2:
                raw = zlib.decompress(raw)
            elif comp == 1:
                raw = gzip.decompress(raw)
            elif comp != 3:
                continue
            yield idx & 31, idx >> 5, parse_nbt(raw)
        except Exception:
            continue


def render_region(path, overworld=True):
    """把一個 .mca 畫成 512x512 RGBA PNG bytes。"""
    W = 512
    heights = [None] * (W * W)
    colors = [None] * (W * W)
    for cx, cz, chunk in iter_region_chunks(path):
        try:
            surf = chunk_surface(chunk, overworld)
        except Exception:
            surf = None
        if not surf:
            continue
        for i, v in enumerate(surf):
            if v is None:
                continue
            x = cx * 16 + (i & 15)
            z = cz * 16 + (i >> 4)
            colors[z * W + x], heights[z * W + x] = v
    px = bytearray(W * W * 4)
    for p in range(W * W):
        c = colors[p]
        if c is None:
            continue
        h = heights[p]
        north = heights[p - W] if p >= W and heights[p - W] is not None else h
        f = 1.0 + max(-0.25, min(0.25, (h - north) * 0.08))
        o = p * 4
        px[o] = min(255, int(c[0] * f)); px[o + 1] = min(255, int(c[1] * f)); px[o + 2] = min(255, int(c[2] * f)); px[o + 3] = 255
    return png_rgba(W, W, px)


def png_rgba(w, h, px):
    raw = bytearray()
    stride = w * 4
    for y in range(h):
        raw.append(0)
        raw += px[y * stride:(y + 1) * stride]

    def chunk(t, d):
        c = t + d
        return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 6)) + chunk(b"IEND", b""))


# ---------------------------------------------------------------- 維度/玩家
def dim_id_from_path(rel):
    r = rel.replace("\\", "/").lower()
    if "dim-1" in r or "the_nether" in r:
        return "minecraft:the_nether"
    if "dim1" in r or "the_end" in r:
        return "minecraft:the_end"
    parts = r.split("/")
    if "dimensions" in parts:
        i = parts.index("dimensions")
        if len(parts) > i + 2:
            return parts[i + 1] + ":" + parts[i + 2]
    return "minecraft:overworld"


def find_dimensions(server_dir, level_name):
    """找出所有含 .mca 的 region 資料夾。回傳 {key: {"path":…, "dim":…}}"""
    out = {}
    for entry in sorted(os.listdir(server_dir)):
        wdir = os.path.join(server_dir, entry)
        if not (os.path.isdir(wdir) and (entry == level_name or entry.startswith(level_name + "_"))):
            continue
        for dirpath, dirs, files in os.walk(wdir):
            depth = os.path.relpath(dirpath, wdir).count(os.sep)
            if depth > 5:
                dirs[:] = []
                continue
            if os.path.basename(dirpath) == "region" and any(f.endswith(".mca") for f in files):
                rel = os.path.relpath(dirpath, server_dir).replace("\\", "/")
                out[rel] = {"path": dirpath, "dim": dim_id_from_path(os.path.relpath(dirpath, wdir))}
    return out


def list_regions(region_dir):
    out = []
    for f in os.listdir(region_dir):
        p = f.split(".")
        if len(p) == 4 and p[0] == "r" and p[3] == "mca":
            try:
                if os.path.getsize(os.path.join(region_dir, f)) > 8192:
                    out.append([int(p[1]), int(p[2])])
            except (ValueError, OSError):
                pass
    return out


def offline_positions(server_dir, level_name):
    """從 playerdata/*.dat 讀取玩家最後位置（伺服器存檔時更新）。"""
    names = {}
    for e in read_json(os.path.join(server_dir, "usercache.json"), []) or []:
        names[e.get("uuid", "").lower()] = e.get("name")
    wdir = os.path.join(server_dir, level_name)
    out = []
    for dirpath, dirs, files in os.walk(wdir):
        if os.path.relpath(dirpath, wdir).count(os.sep) > 3:
            dirs[:] = []
            continue
        if os.path.basename(dirpath) != "playerdata":
            continue
        for f in files:
            if not f.endswith(".dat"):
                continue
            uuid = f[:-4].lower()
            try:
                nbt = read_nbt_file(os.path.join(dirpath, f))
                pos = nbt.get("Pos") or [0, 0, 0]
                dim = nbt.get("Dimension", "minecraft:overworld")
                if isinstance(dim, int):
                    dim = {-1: "minecraft:the_nether", 1: "minecraft:the_end"}.get(dim, "minecraft:overworld")
                out.append({"uuid": uuid, "name": names.get(uuid) or uuid[:8],
                            "x": pos[0], "y": pos[1], "z": pos[2], "dim": dim})
            except Exception:
                continue
    return out
