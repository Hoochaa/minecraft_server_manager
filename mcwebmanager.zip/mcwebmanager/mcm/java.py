"""獨立 Java 執行環境管理。

Java 一律下載到 data/runtimes/java-<版本>/ 裡，只用「完整路徑」呼叫，
不會動到系統的 PATH、JAVA_HOME 或登錄檔，所以不會影響電腦原本的環境。
"""
import os
import platform
import shutil
import tarfile
import threading
import zipfile

from .util import RUNTIMES_DIR, CACHE_DIR, download

ADOPTIUM_LTS = [8, 11, 17, 21, 25]
_locks = {}
_locks_guard = threading.Lock()


def pick_feature(major):
    """把 Minecraft 要求的 Java 版本對應到 Adoptium 有提供的 LTS 版本（例如 16 → 17）。"""
    major = int(major or 8)
    for v in ADOPTIUM_LTS:
        if v >= major:
            return v
    return major


def _os_arch():
    s = platform.system().lower()
    os_name = {"windows": "windows", "darwin": "mac", "linux": "linux"}.get(s, "linux")
    m = platform.machine().lower()
    arch = "aarch64" if m in ("arm64", "aarch64") else ("x32" if m in ("i386", "i686", "x86") else "x64")
    return os_name, arch


def _find_java(root):
    exe = "java.exe" if os.name == "nt" else "java"
    for dirpath, _dirs, files in os.walk(root):
        if exe in files and os.path.basename(dirpath) == "bin":
            return os.path.join(dirpath, exe)
    return None


def java_path(major):
    """已安裝則回傳 java 執行檔路徑，否則 None。"""
    root = os.path.join(RUNTIMES_DIR, f"java-{pick_feature(major)}")
    return _find_java(root) if os.path.isdir(root) else None


def installed():
    out = []
    for name in sorted(os.listdir(RUNTIMES_DIR)):
        if name.startswith("java-"):
            p = _find_java(os.path.join(RUNTIMES_DIR, name))
            if p:
                out.append({"version": name[5:], "path": p})
    return out


def ensure_java(major, log=print):
    feature = pick_feature(major)
    with _locks_guard:
        lock = _locks.setdefault(feature, threading.Lock())
    with lock:
        p = java_path(feature)
        if p:
            return p
        os_name, arch = _os_arch()
        log(f"正在下載獨立 Java {feature}（{os_name}/{arch}），只會放在 data/runtimes，不影響系統環境…")
        ext = "zip" if os_name == "windows" else "tar.gz"
        archive = os.path.join(CACHE_DIR, f"java-{feature}-{os_name}-{arch}.{ext}")
        last_err = None
        for image in ("jre", "jdk"):
            url = (f"https://api.adoptium.net/v3/binary/latest/{feature}/ga/"
                   f"{os_name}/{arch}/{image}/hotspot/normal/eclipse")
            try:
                download(url, archive, log)
                break
            except Exception as e:  # 某些版本沒有 JRE，改抓 JDK
                last_err = e
                log(f"  {image} 下載失敗（{e}），嘗試下一個…")
        else:
            raise RuntimeError(f"無法下載 Java {feature}：{last_err}")

        dest = os.path.join(RUNTIMES_DIR, f"java-{feature}")
        tmp = dest + ".extract"
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        log("  解壓縮 Java…")
        if ext == "zip":
            with zipfile.ZipFile(archive) as z:
                z.extractall(tmp)
        else:
            with tarfile.open(archive) as t:
                try:
                    t.extractall(tmp, filter="data")
                except TypeError:
                    t.extractall(tmp)
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(tmp, dest)
        try:
            os.remove(archive)
        except OSError:
            pass
        p = _find_java(dest)
        if not p:
            raise RuntimeError("解壓縮後找不到 java 執行檔")
        if os.name != "nt":
            os.chmod(p, 0o755)
        log(f"Java {feature} 安裝完成：{p}")
        return p
