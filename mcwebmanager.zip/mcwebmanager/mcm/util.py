"""共用工具：路徑、設定檔、HTTP 下載。"""
import json
import os
import ssl
import threading
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
SERVERS_DIR = os.path.join(DATA, "servers")
RUNTIMES_DIR = os.path.join(DATA, "runtimes")
CACHE_DIR = os.path.join(DATA, "cache")
WEB_DIR = os.path.join(ROOT, "web")
CONFIG_PATH = os.path.join(DATA, "config.json")

DEFAULT_CONFIG = {
    "host": "0.0.0.0",          # 0.0.0.0 = 內網其他電腦也能連入
    "port": 8080,
    "password": "",             # 留空 = 不需登入；設定後瀏覽器會跳出帳密視窗（帳號隨意）
    "user_agent": "MCWebManager/1.0 (self-hosted Minecraft server manager)",
}

for d in (DATA, SERVERS_DIR, RUNTIMES_DIR, CACHE_DIR):
    os.makedirs(d, exist_ok=True)


def read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(read_json(CONFIG_PATH, {}) or {})
    if not os.path.exists(CONFIG_PATH):
        write_json(CONFIG_PATH, cfg)
    return cfg


CONFIG = load_config()
_ctx = ssl.create_default_context()


def _request(url):
    return urllib.request.Request(url, headers={"User-Agent": CONFIG.get("user_agent") or DEFAULT_CONFIG["user_agent"]})


def http_json(url, timeout=30):
    with urllib.request.urlopen(_request(url), timeout=timeout, context=_ctx) as r:
        return json.loads(r.read().decode("utf-8"))


_cache_lock = threading.Lock()
_mem_cache = {}


def cached_json(url, ttl=600):
    """有記憶體快取的 JSON 取得（版本清單之類）。"""
    import time
    with _cache_lock:
        hit = _mem_cache.get(url)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    data = http_json(url)
    with _cache_lock:
        _mem_cache[url] = (time.time(), data)
    return data


def download(url, dest, log=None):
    """下載檔案到 dest，log(msg) 回報進度。"""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    with urllib.request.urlopen(_request(url), timeout=60, context=_ctx) as r:
        total = int(r.headers.get("Content-Length") or 0)
        got, last = 0, -1
        with open(tmp, "wb") as f:
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if log and total:
                    pct = got * 100 // total
                    if pct // 10 != last:
                        last = pct // 10
                        log(f"  下載中 {os.path.basename(dest)}：{pct}% ({got // 1048576}/{total // 1048576} MB)")
    os.replace(tmp, dest)
    return dest


def safe_join(base, *parts):
    """防止路徑跳脫（../）。"""
    base = os.path.abspath(base)
    p = os.path.abspath(os.path.join(base, *parts))
    if p != base and not p.startswith(base + os.sep):
        raise ValueError("非法路徑")
    return p
