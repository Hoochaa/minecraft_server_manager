"""伺服器運行器（核心）版本查詢與自動安裝。"""
import glob
import os
import shlex
import subprocess

from .util import cached_json, download
from . import java as javamod

MOJANG_MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

TYPES = {
    "vanilla":  {"name": "Vanilla 原版",  "loader": False, "addon_dir": None},
    "paper":    {"name": "Paper（插件）", "loader": False, "addon_dir": "plugins"},
    "purpur":   {"name": "Purpur（插件）", "loader": False, "addon_dir": "plugins"},
    "fabric":   {"name": "Fabric（模組）", "loader": True,  "addon_dir": "mods"},
    "forge":    {"name": "Forge（模組）",  "loader": True,  "addon_dir": "mods"},
    "neoforge": {"name": "NeoForge（模組）", "loader": True, "addon_dir": "mods"},
}


# ---------------------------------------------------------------- 版本清單
def mojang_versions(snapshots=False):
    data = cached_json(MOJANG_MANIFEST)
    return [v["id"] for v in data["versions"] if snapshots or v["type"] == "release"]


def mojang_version_json(mc):
    data = cached_json(MOJANG_MANIFEST)
    for v in data["versions"]:
        if v["id"] == mc:
            return cached_json(v["url"], ttl=86400)
    raise RuntimeError(f"找不到 Minecraft 版本 {mc}")


def required_java(mc):
    try:
        return int(mojang_version_json(mc).get("javaVersion", {}).get("majorVersion", 8))
    except Exception:
        return 21


def _neo_to_mc(v):
    """NeoForge 版本號 → Minecraft 版本。21.1.233→1.21.1、20.4.x→1.20.4、26.1.2.76→26.1.2、26.3.0.100→26.3"""
    base = v.split("-")[0].split("+")[0]
    p = base.split(".")
    try:
        major = int(p[0])
    except ValueError:
        return None
    if major >= 26 and len(p) >= 4:
        return p[0] + "." + p[1] + ("" if p[2] == "0" else "." + p[2])
    if len(p) >= 3:
        return "1." + p[0] + ("" if p[1] == "0" else "." + p[1])
    return None


def game_versions(stype, snapshots=False):
    if stype == "vanilla":
        return mojang_versions(snapshots)
    if stype == "paper":
        data = cached_json("https://fill.papermc.io/v3/projects/paper")
        out = []
        for group in data["versions"].values():
            out.extend(group)
        out = [v for v in out if snapshots or ("pre" not in v and "rc" not in v and "snapshot" not in v)]
        order = {v: i for i, v in enumerate(mojang_versions(True))}
        return sorted(out, key=lambda v: order.get(v, 99999))
    if stype == "purpur":
        return list(reversed(cached_json("https://api.purpurmc.org/v2/purpur")["versions"]))
    if stype == "fabric":
        return [g["version"] for g in cached_json("https://meta.fabricmc.net/v2/versions/game")
                if snapshots or g["stable"]]
    if stype == "forge":
        promos = cached_json("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")["promos"]
        mcs = {k.rsplit("-", 1)[0] for k in promos}
        order = {v: i for i, v in enumerate(mojang_versions(True))}
        return sorted(mcs, key=lambda v: order.get(v, 99999))
    if stype == "neoforge":
        vs = cached_json("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")["versions"]
        mcs = {m for m in (_neo_to_mc(v) for v in vs) if m}
        order = {v: i for i, v in enumerate(mojang_versions(True))}
        return sorted((m for m in mcs if m in order), key=lambda v: order[v])
    raise ValueError("未知的伺服器類型")


def loader_versions(stype, mc):
    if stype == "fabric":
        return [l["loader"]["version"] for l in cached_json(f"https://meta.fabricmc.net/v2/versions/loader/{mc}")]
    if stype == "forge":
        promos = cached_json("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")["promos"]
        out = []
        for tag in ("recommended", "latest"):
            v = promos.get(f"{mc}-{tag}")
            if v and v not in out:
                out.append(v)
        return out
    if stype == "neoforge":
        vs = cached_json("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")["versions"]
        return list(reversed([v for v in vs if _neo_to_mc(v) == mc]))
    return []


# ---------------------------------------------------------------- 安裝
def install(inst, log):
    """下載並安裝伺服器核心，回傳 launch 設定 dict。"""
    m = inst.meta
    stype, mc, loader = m["type"], m["mc_version"], m.get("loader_version") or ""
    d = inst.dir
    java_major = m.get("java") or required_java(mc)
    m["java"] = javamod.pick_feature(java_major)
    java = javamod.ensure_java(java_major, log)

    if stype == "vanilla":
        url = mojang_version_json(mc)["downloads"]["server"]["url"]
        log(f"下載 Vanilla {mc} 伺服器…")
        download(url, os.path.join(d, "server.jar"), log)
        return {"mode": "jar", "jar": "server.jar"}

    if stype == "paper":
        b = cached_json(f"https://fill.papermc.io/v3/projects/paper/versions/{mc}/builds/latest", ttl=60)
        url = b["downloads"]["server:default"]["url"]
        log(f"下載 Paper {mc} build {b.get('id')}…")
        download(url, os.path.join(d, "server.jar"), log)
        return {"mode": "jar", "jar": "server.jar"}

    if stype == "purpur":
        log(f"下載 Purpur {mc}…")
        download(f"https://api.purpurmc.org/v2/purpur/{mc}/latest/download", os.path.join(d, "server.jar"), log)
        return {"mode": "jar", "jar": "server.jar"}

    if stype == "fabric":
        if not loader:
            loader = loader_versions("fabric", mc)[0]
            m["loader_version"] = loader
        inst_ver = cached_json("https://meta.fabricmc.net/v2/versions/installer")[0]["version"]
        log(f"下載 Fabric loader {loader}（MC {mc}）…")
        download(f"https://meta.fabricmc.net/v2/versions/loader/{mc}/{loader}/{inst_ver}/server/jar",
                 os.path.join(d, "server.jar"), log)
        return {"mode": "jar", "jar": "server.jar"}

    if stype in ("forge", "neoforge"):
        if not loader:
            loader = loader_versions(stype, mc)[0]
            m["loader_version"] = loader
        if stype == "forge":
            full = f"{mc}-{loader}"
            url = f"https://maven.minecraftforge.net/net/minecraftforge/forge/{full}/forge-{full}-installer.jar"
        else:
            url = f"https://maven.neoforged.net/releases/net/neoforged/neoforge/{loader}/neoforge-{loader}-installer.jar"
        installer = os.path.join(d, "installer.jar")
        log(f"下載 {stype} 安裝程式 {loader}…")
        download(url, installer, log)
        log("執行安裝程式（--installServer），這可能需要幾分鐘…")
        p = subprocess.Popen([java, "-jar", "installer.jar", "--installServer"], cwd=d,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
        for raw in p.stdout:
            line = raw.decode("utf-8", "replace").rstrip()
            if line:
                log("  " + line)
        if p.wait() != 0:
            raise RuntimeError("安裝程式執行失敗")
        for f in ("installer.jar", "installer.jar.log"):
            try:
                os.remove(os.path.join(d, f))
            except OSError:
                pass
        return detect_forge_launch(d)

    raise ValueError("未知的伺服器類型")


def detect_forge_launch(d):
    """解析安裝程式產生的 run.sh（新版 Forge/NeoForge），或找出舊版 forge-*.jar。"""
    run_sh = os.path.join(d, "run.sh")
    if os.path.exists(run_sh):
        with open(run_sh, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("#") or "java" not in line.split(" ")[0]:
                    continue
                toks = shlex.split(line)[1:]
                toks = [t for t in toks if t not in ("$@", "@user_jvm_args.txt", "nogui")]
                if os.name == "nt":
                    toks = [t.replace("unix_args.txt", "win_args.txt") for t in toks]
                if toks:
                    return {"mode": "args", "args": toks}
    for pat in ("libraries/net/neoforged/neoforge/*/", "libraries/net/minecraftforge/forge/*/"):
        for folder in glob.glob(os.path.join(d, pat)):
            f = os.path.join(folder, "win_args.txt" if os.name == "nt" else "unix_args.txt")
            if os.path.exists(f):
                return {"mode": "args", "args": ["@" + os.path.relpath(f, d).replace("\\", "/")]}
    jars = [j for j in glob.glob(os.path.join(d, "*.jar"))
            if "installer" not in j and ("forge" in os.path.basename(j).lower())]
    if jars:
        return {"mode": "jar", "jar": os.path.basename(sorted(jars)[-1])}
    raise RuntimeError("安裝完成但找不到啟動方式（run.sh / forge jar）")
